package com.sdk.wisetracker.dox.tracker.manager;

import android.webkit.WebView;

import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.WebViewManager;

/**
 * 웹뷰 설정 manager class
 */
public class DoxWebViewManager extends WebViewManager {

    private final String DOX_WEB_INTERFACE = "DOX_JS_INTERFACE";
    private static DoxWebViewManager instance = null;
    private WebView webView = null;

    public static DoxWebViewManager getInstance() {
        if (instance == null) {
            instance = new DoxWebViewManager();
        }
        return instance;
    }

    public void setWebView(WebView webView) {
        try {
            if (webView == null) {
                WiseLog.d("web view is null");
                return;
            }
            this.webView = webView;
            this.webView.getSettings().setJavaScriptEnabled(true);
            this.webView.addJavascriptInterface(new DoxWebInterfaceManager(), DOX_WEB_INTERFACE);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

}

package com.sdk.wisetracker.dox.tracker.network;

import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.network.BaseRetrofit;
import com.sdk.wisetracker.base.tracker.network.interceptor.RetrofitHeaderInterceptor;
import com.sdk.wisetracker.base.tracker.network.interceptor.RetrofitLogInterceptor;
import com.sdk.wisetracker.base.tracker.network.type.HeaderType;

import okhttp3.Interceptor;

/**
 * 네트워크 설정 util class
 */
public class DoxRetrofit extends BaseRetrofit<DoxApi> {

    private static DoxRetrofit instance = null;

    public static DoxRetrofit getInstance() {
        if (instance == null) {
            instance = new DoxRetrofit();
        }
        return instance;
    }

    @Override
    public String getTag() {
        return "DoxRetrofit";
    }

    // 전송 URL
    @Override
    public String getUrl() {
        return SessionDataManager.getInstance().getSession().getDomainX();
    }

    @Override
    public Interceptor getHeaderInterceptor(HeaderType type) {
        return new RetrofitHeaderInterceptor(getTag(), type);
    }

    @Override
    public Interceptor getLogInterceptor() {
        return new RetrofitLogInterceptor(getTag());
    }

}
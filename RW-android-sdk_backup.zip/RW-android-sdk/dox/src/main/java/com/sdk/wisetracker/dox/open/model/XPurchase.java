package com.sdk.wisetracker.dox.open.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

import java.util.ArrayList;
import java.util.List;

/**
 * XPurchase 모델 class
 */
public class XPurchase implements IJsonElement {

    private @SerializedName("ordNo") String orderNo;
    private @SerializedName("eventType") String revenueType;
    private @SerializedName("curcy") String currency;
    private @SerializedName("product") List<XProduct> productList;
    private @SerializedName("properties") XProperties xProperties;

    public XPurchase(Builder builder) {
        orderNo = builder.orderNo;
        revenueType = builder.revenueType;
        currency = builder.currency;
        productList = builder.productList;
        xProperties = builder.xProperties;
    }

    public List<XProduct> getProductList() {
        return productList;
    }

    public void setXProperties(XProperties xProperties) {
        this.xProperties = xProperties;
    }

    public static class Builder {

        private String orderNo = null;
        private String revenueType = null;
        private String currency = null;
        private List<XProduct> productList = null;
        private XProperties xProperties = null;

        public Builder setOrderNo(String orderNo) {
            this.orderNo = orderNo;
            return this;
        }

        public Builder setRevenueType(String revenueType) {
            this.revenueType = revenueType;
            return this;
        }

        public Builder setCurrency(String currency) {
            this.currency = currency;
            return this;
        }

        public Builder setProductList(List<XProduct> productList) {
            this.productList = productList;
            return this;
        }

        public Builder setProduct(XProduct product) {
            if (this.productList == null) {
                this.productList = new ArrayList<>();
            }
            productList.add(product);
            return this;
        }

        public Builder setProperties(XProperties xProperties) {
            this.xProperties = xProperties;
            return this;
        }

        public XPurchase build() {
            return new XPurchase(this);
        }

    }

    @Override
    public JsonElement getJsonElement() {
        try {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("ordNo", orderNo);
            jsonObject.addProperty("eventType", revenueType);
            jsonObject.addProperty("curcy", currency);
            if (productList != null && !productList.isEmpty()) {
                JsonArray jsonArray = new JsonArray();
                for (IJsonElement iJsonElement : productList) {
                    jsonArray.add(iJsonElement.getJsonElement());
                }
                jsonObject.add("products", jsonArray);
            }
            if (xProperties != null && xProperties.getJsonElement() != null) {
                jsonObject.add("properties", xProperties.getJsonElement());
            }
            return jsonObject;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

}

package com.sdk.wisetracker.dox.open.model;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * XProperties 모델 class
 */
public class XProperties implements IJsonElement {

    private Map<String, Object> identifyMap;

    public XProperties(Builder builder) {
        identifyMap = builder.identifyMap;
    }

    public XProperties(Map<String, Object> identifyMap) {
        this.identifyMap = identifyMap;
    }

    public static class Builder {

        private Map<String, Object> identifyMap = new HashMap<>();

        public Builder set(String key, Object value) {
            identifyMap.put(key, value);
            return this;
        }

        public XProperties build() {
            return new XProperties(this);
        }

    }

    @Override
    public JsonElement getJsonElement() {

        try {

            if (identifyMap == null) {
                return null;
            }

            String xPropertyJson = new Gson().toJson(identifyMap);
            JsonElement originalElement = new JsonParser().parse(xPropertyJson);
            if (originalElement.isJsonObject()) {
                JsonObject jsonObject = originalElement.getAsJsonObject();
                JsonElement resultEle = iterator(new JsonObject(), jsonObject.entrySet().iterator());
                return resultEle;
            }

        } catch (Exception e) {
            WiseLog.e(e);
        }

        return null;

    }

    private JsonElement iterator(JsonObject jsonObject, Iterator<Map.Entry<String, JsonElement>> iterator) {

        while (iterator.hasNext()) {

            Map.Entry<String, JsonElement> map = iterator.next();
            JsonElement jsonElement = map.getValue();
            if (jsonElement.isJsonObject()) {
                JsonElement subJsonElement = jsonElement.getAsJsonObject().get("identifyMap");
                if (subJsonElement.isJsonObject()) {
                    jsonObject.add(map.getKey(), iterator(new JsonObject(), subJsonElement.getAsJsonObject().entrySet().iterator()));
                } else {
                    jsonObject.add(map.getKey(), subJsonElement);
                }
            } else {
                jsonObject.add(map.getKey(), map.getValue());
            }

        }

        return jsonObject;

    }

}

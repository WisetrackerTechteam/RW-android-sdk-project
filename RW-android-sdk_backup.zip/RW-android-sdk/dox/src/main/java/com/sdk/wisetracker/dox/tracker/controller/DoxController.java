package com.sdk.wisetracker.dox.tracker.controller;

import android.webkit.WebView;

import com.sdk.wisetracker.base.open.controller.BaseController;
import com.sdk.wisetracker.dox.open.model.XConversion;
import com.sdk.wisetracker.dox.open.model.XEvent;
import com.sdk.wisetracker.dox.open.model.XIdentify;
import com.sdk.wisetracker.dox.open.model.XPurchase;
import com.sdk.wisetracker.dox.tracker.manager.DoxManager;
import com.sdk.wisetracker.dox.tracker.model.XGroupProperty;

/**
 * DOX 이벤트 관련 처리 controller
 */
public class DoxController extends BaseController {

    public static void groupIdentify(String key, String value, XIdentify identify) {
        XGroupProperty groupProperty = new XGroupProperty();
        groupProperty.setGroups(key, value);
        groupProperty.setGroupIdentify(identify);
        DoxManager.getInstance().setGroupIdentify(groupProperty);
    }

    public static void userIdentify(XIdentify identify) {
        DoxManager.getInstance().setUserIdentify(identify);
    }

    public static void logEvent(XEvent event) {
        DoxManager.getInstance().setLogEvent(event);
    }

    public static void logConversion(XConversion conversion) {
        DoxManager.getInstance().setLogConversion(conversion);
    }

    public static void logPurchase(XPurchase purchase) {
        DoxManager.getInstance().setLogPurchase(purchase);
    }

    public static void setWebView(WebView webView) {
        DoxManager.getInstance().setWebView(webView);
    }

    public static void injectJavascript(WebView webView) {
        DoxManager.getInstance().injectJavascript(webView);
    }

}

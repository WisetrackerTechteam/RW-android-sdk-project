package com.sdk.wisetracker.dox.open.model;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.annotations.SerializedName;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

import java.util.HashMap;
import java.util.Map;

/**
 * XIdentify 모델 class
 */
public class XIdentify implements IJsonElement {

    private @SerializedName("$set") Map<String, Object> setMap;
    private @SerializedName("$setOnce") Map<String, Object> setOnceMap;
    private @SerializedName("$unset") Map<String, String> unsetMap;
    private @SerializedName("$add") Map<String, Integer> addMap;
    private @SerializedName("$append") Map<String, Object> appendMap;
    private @SerializedName("$prepend") Map<String, Object> prependMap;

    public XIdentify(Builder builder) {
        setMap = builder.setMap;
        setOnceMap = builder.setOnceMap;
        unsetMap = builder.unsetMap;
        addMap = builder.addMap;
        appendMap = builder.appendMap;
        prependMap = builder.prependMap;
    }

    public static class Builder {

        private Map<String, Object> setMap = null;
        private Map<String, Object> setOnceMap = null;
        private Map<String, String> unsetMap = null;
        private Map<String, Integer> addMap = null;
        private Map<String, Object> appendMap = null;
        private Map<String, Object> prependMap = null;

        public Builder set(String key, Object value) {
            if (setMap == null) {
                setMap = new HashMap<>();
            }
            setMap.put(key, value);
            return this;
        }

        public Builder setOnce(String key, Object value) {
            if (setOnceMap == null) {
                setOnceMap = new HashMap<>();
            }
            setOnceMap.put(key, value);
            return this;
        }

        public Builder unset(String key) {
            if (unsetMap == null) {
                unsetMap = new HashMap<>();
            }
            unsetMap.put(key, "");
            return this;
        }

        public Builder add(String key, int increment) {
            if (addMap == null) {
                addMap = new HashMap<>();
            }
            addMap.put(key, increment);
            return this;
        }

        public Builder append(String key, Object value) {
            if (appendMap == null) {
                appendMap = new HashMap<>();
            }
            appendMap.put(key, value);
            return this;
        }

        public Builder prepend(String key, Object value) {
            if (prependMap == null) {
                prependMap = new HashMap<>();
            }
            prependMap.put(key, value);
            return this;
        }

        public XIdentify build() {
            return new XIdentify(this);
        }

    }

    @Override
    public JsonElement getJsonElement() {
        try {
            String xIdentifyString = new Gson().toJson(this);
            JsonElement element = new JsonParser().parse(xIdentifyString);
            return element;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

}
package com.sdk.wisetracker.dox.tracker.network;

import io.reactivex.Observable;
import okhttp3.ResponseBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * DOX 이벤트 데이터 전송 API
 */
public interface DoxApi {

    @POST("gsshop.html")
    Observable<ResponseBody> sendTransaction(@Body String body);

}

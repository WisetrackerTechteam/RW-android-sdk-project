package com.sdk.wisetracker.dox.open.api;

import android.content.Context;
import android.webkit.WebView;

import com.sdk.wisetracker.dox.open.model.XConversion;
import com.sdk.wisetracker.dox.open.model.XEvent;
import com.sdk.wisetracker.dox.open.model.XIdentify;
import com.sdk.wisetracker.dox.open.model.XPurchase;
import com.sdk.wisetracker.dox.tracker.controller.DoxController;

public class DOX {

    public static void initialization(Context context) {
        //DoxController.init(context);
    }

    /**
     * GroupIdentify 호출 API
     * @param key
     * @param value
     * @param identify
     */
    public static void groupIdentify(String key, String value, XIdentify identify) {
        DoxController.groupIdentify(key, value, identify);
    }

    /**
     * UserIdentify 호출 API
     * @param identify
     */
    public static void userIdentify(XIdentify identify) {
        DoxController.userIdentify(identify);
    }

    /**
     * XEvent 데이터 호출 API
     * @param event
     */
    public static void logXEvent(XEvent event) {
        DoxController.logEvent(event);
    }

    /**
     * XConversion 데이터 호출 API
     * @param conversion
     */
    public static void logXConversion(XConversion conversion) {
        DoxController.logConversion(conversion);
    }

    /**
     * XPurchase 데이터 호출 API
     * @param purchase
     */
    public static void logXPurchase(XPurchase purchase) {
        DoxController.logPurchase(purchase);
    }

    /**
     * 웹뷰 설정 API
     * 웹뷰 로드시 호출
     * @param webView
     */
    public static void setWebView(WebView webView) {
        DoxController.setWebView(webView);
    }

    /**
     * 웹뷰 이용시 .js 파일 인젝트를 위해 호출 API
     * @param webView
     */
    public static void injectJavascript(WebView webView) {
        DoxController.injectJavascript(webView);
    }

}
package com.sdk.wisetracker.dox.tracker.model;

import android.text.TextUtils;

import com.sdk.wisetracker.dox.open.model.XIdentify;

import java.util.HashMap;
import java.util.Map;

/**
 * XGroupProperty 내부 사용 모델 class
 */
public class XGroupProperty {

    private Map<String, String> groupsMap = null;
    private XIdentify groupIdentify = null;

    public Map<String, String> getGroupsMap() {
        return groupsMap;
    }

    public void setGroups(String key, String value) {
        if (this.groupsMap == null) {
            this.groupsMap = new HashMap<>();
        }
        if (!TextUtils.isEmpty(key)) {
            this.groupsMap.put(key, value);
        }
    }

    public XIdentify getGroupIdentify() {
        return groupIdentify;
    }

    public void setGroupIdentify(XIdentify groupIdentify) {
        this.groupIdentify = groupIdentify;
    }

}

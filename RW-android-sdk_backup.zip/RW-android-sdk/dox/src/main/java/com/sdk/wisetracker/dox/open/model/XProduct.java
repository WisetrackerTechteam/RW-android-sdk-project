package com.sdk.wisetracker.dox.open.model;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

/**
 * XProduct 모델 class
 */
public class XProduct implements IJsonElement {

    private @SerializedName("pg1") String firstCategory;
    private @SerializedName("pg2") String secondCategory;
    private @SerializedName("pg3") String thirdCategory;
    private @SerializedName("pg4") String detailCategory;
    private @SerializedName("pnc") String productCode;
    private @SerializedName("amt") double orderAmount;
    private @SerializedName("ea") long orderQuantity;
    private @SerializedName("ordPno") String productOrderNo;
    private @SerializedName("properties") XProperties properties;

    public XProduct(Builder builder) {
        firstCategory = builder.firstCategory;
        secondCategory = builder.secondCategory;
        thirdCategory = builder.thirdCategory;
        detailCategory = builder.detailCategory;
        productCode = builder.productCode;
        orderAmount = builder.orderAmount;
        orderQuantity = builder.orderQuantity;
        productOrderNo = builder.productOrderNo;
        properties = builder.properties;
    }

    public void setProperties(XProperties properties) {
        this.properties = properties;
    }

    public static class Builder {

        private String firstCategory = null;
        private String secondCategory = null;
        private String thirdCategory = null;
        private String detailCategory = null;
        private String productCode = null;
        private double orderAmount = 0;
        private long orderQuantity = 0;
        private String productOrderNo = null;
        private XProperties properties = null;

        public Builder setFirstCategory(String firstCategory) {
            this.firstCategory = firstCategory;
            return this;
        }

        public Builder setSecondCategory(String secondCategory) {
            this.secondCategory = secondCategory;
            return this;
        }

        public Builder setThirdCategory(String thirdCategory) {
            this.thirdCategory = thirdCategory;
            return this;
        }

        public Builder setDetailCategory(String detailCategory) {
            this.detailCategory = detailCategory;
            return this;
        }

        public Builder setProductCode(String productCode) {
            this.productCode = productCode;
            return this;
        }

        public Builder setOrderAmount(double orderAmount) {
            this.orderAmount = orderAmount;
            return this;
        }

        public Builder setOrderQuantity(long orderQuantity) {
            this.orderQuantity = orderQuantity;
            return this;
        }

        public Builder setProductOrderNo(String productOrderNo) {
            this.productOrderNo = productOrderNo;
            return this;
        }

        public Builder setProperties(XProperties properties) {
            this.properties = properties;
            return this;
        }

        public XProduct build() {
            return new XProduct(this);
        }

    }

    @Override
    public JsonElement getJsonElement() {
        try {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("pg1", firstCategory);
            jsonObject.addProperty("pg2", secondCategory);
            jsonObject.addProperty("pg3", thirdCategory);
            jsonObject.addProperty("pg4", detailCategory);
            jsonObject.addProperty("pnc", productCode);
            jsonObject.addProperty("amt", orderAmount);
            jsonObject.addProperty("ea", orderQuantity);
            jsonObject.addProperty("productOrderNo", productOrderNo);
            if (properties != null && properties.getJsonElement() != null) {
                jsonObject.add("properties", properties.getJsonElement());
            }
            return jsonObject;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

}

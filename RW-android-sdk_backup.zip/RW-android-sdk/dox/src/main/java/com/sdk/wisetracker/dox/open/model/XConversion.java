package com.sdk.wisetracker.dox.open.model;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

/**
 * XConversion 모델 class
 */
public class XConversion implements IJsonElement {

    private @SerializedName("cvrname") String eventName;
    private @SerializedName("properties") XProperties xProperties;

    public XConversion(Builder builder) {
        eventName = builder.eventName;
        xProperties = builder.xProperties;
    }

    public void setXProperties(XProperties xProperties) {
        this.xProperties = xProperties;
    }

    public static class Builder {

        private String eventName;
        private XProperties xProperties = null;

        public Builder setEventName(String eventName) {
            this.eventName = eventName;
            return this;
        }

        public Builder setProperties(XProperties xProperties) {
            this.xProperties = xProperties;
            return this;
        }

        public XConversion build() {
            return new XConversion(this);
        }

    }

    @Override
    public JsonElement getJsonElement() {
        try {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("evtname", eventName);
            if (xProperties != null && xProperties.getJsonElement() != null) {
                jsonObject.add("properties", xProperties.getJsonElement());
            }
            return jsonObject;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

}

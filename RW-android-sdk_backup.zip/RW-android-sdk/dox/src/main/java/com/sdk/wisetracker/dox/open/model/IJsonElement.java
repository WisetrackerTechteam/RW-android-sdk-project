package com.sdk.wisetracker.dox.open.model;

import com.google.gson.JsonElement;

/**
 * 모델 클래스에서 json 추출 interface
 */
public interface IJsonElement {
    JsonElement getJsonElement();
}

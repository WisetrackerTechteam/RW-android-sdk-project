package com.sdk.wisetracker.dox.tracker.manager;

import android.text.TextUtils;
import android.webkit.JavascriptInterface;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.dox.open.api.DOX;
import com.sdk.wisetracker.dox.open.model.XConversion;
import com.sdk.wisetracker.dox.open.model.XEvent;
import com.sdk.wisetracker.dox.open.model.XIdentify;
import com.sdk.wisetracker.dox.open.model.XProduct;
import com.sdk.wisetracker.dox.open.model.XProperties;
import com.sdk.wisetracker.dox.open.model.XPurchase;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 웹뷰 <-> SDK 연동 브릿지 class
 */
public class DoxWebInterfaceManager {

    @JavascriptInterface
    public void groupIdentify(String key, String value, String json) {
        WiseLog.d("webview groupIdentify");
        XIdentify xIdentify = new Gson().fromJson(json, XIdentify.class);
        if (xIdentify == null) {
            WiseLog.d("convert xIdentify data is null");
            return;
        }
        DOX.groupIdentify(key, value, xIdentify);
    }

    @JavascriptInterface
    public void userIdentify(String json) {
        WiseLog.d("webview userIdentify");
        XIdentify xIdentify = new Gson().fromJson(json, XIdentify.class);
        if (xIdentify == null) {
            WiseLog.d("convert xIdentify data is null");
            return;
        }
        DOX.userIdentify(xIdentify);
    }

    @JavascriptInterface
    public void logXEvent(String json) {
        WiseLog.d("webview logXEvent");
        XEvent xEvent = new Gson().fromJson(json, XEvent.class);
        if (xEvent == null) {
            WiseLog.d("convert xEvent data is null");
            return;
        }
        xEvent.setXProperties(getXProperties(json));
        DOX.logXEvent(xEvent);
    }

    @JavascriptInterface
    public void logXConversion(String json) {
        WiseLog.d("webview logXConversion");
        XConversion xConversion = new Gson().fromJson(json, XConversion.class);
        if (xConversion == null) {
            WiseLog.d("convert xConversion data is null");
            return;
        }
        xConversion.setXProperties(getXProperties(json));
        DOX.logXConversion(xConversion);
    }

    @JavascriptInterface
    public void logXPurchase(String json) {
        WiseLog.d("webview logXPurchase");
        XPurchase xPurchase = new Gson().fromJson(json, XPurchase.class);
        if (xPurchase == null) {
            WiseLog.d("convert xPurchase data is null");
            return;
        }
        xPurchase.setXProperties(getXProperties(json));
        setProductXProperties(xPurchase, json);
        DOX.logXPurchase(xPurchase);
    }

    private XProperties getXProperties(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject == null || !jsonObject.has("properties")) {
                return null;
            }
            String properties = jsonObject.get("properties").toString();
            if (TextUtils.isEmpty(properties)) {
                return null;
            }
            Type type = new TypeToken<Map<String, Object>>() {
            }.getType();
            Map<String, Object> propertiesMap = new Gson().fromJson(properties, type);
            if (propertiesMap == null) {
                return null;
            }
            XProperties xProperties = new XProperties(propertiesMap);
            return xProperties;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

    private void setProductXProperties(XPurchase xPurchase, String json) {

        try {

            List<XProduct> xProductList = xPurchase.getProductList();
            if (xProductList == null || xProductList.isEmpty()) {
                return;
            }

            List<XProperties> xPropertiesList = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject == null) {
                return;
            }

            JSONArray jsonArray = jsonObject.getJSONArray("product");
            if (jsonArray == null || jsonArray.length() == 0) {
                return;
            }

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject productObject = jsonArray.getJSONObject(i);
                if (productObject == null) {
                    continue;
                }
                XProperties xProperties = getXProperties((productObject.toString()));
                if (xProperties == null) {
                    continue;
                }
                xPropertiesList.add(xProperties);
            }

            for (int i = 0; i < xProductList.size(); i++) {
                xProductList.get(i).setProperties(xPropertiesList.get(i));
            }

        } catch (Exception e) {
            WiseLog.e(e);
        }

    }

}


//    @JavascriptInterface
//    public void groupIdentify(String key, String value, String json) {
//        try {
//            Map<String, String> map = new HashMap<>();
//            map.put("key", key);
//            map.put("value", value);
//            map.put("data", json);
//            map.put("type", "group_identify");
//            WebViewManager.getInstance().setData(map);
//            DoxManager.getInstance().setGroupIdentify();
//        } catch (Exception e) {
//            WiseLog.e(e);
//        }
//    }
//
//    @JavascriptInterface
//    public void userIdentify(String json) {
//        try {
//            Map<String, String> map = new HashMap<>();
//            map.put("type", "user_identify");
//            map.put("data", json);
//            WebViewManager.getInstance().setData(map);
//        } catch (Exception e) {
//            WiseLog.e(e);
//        }
//    }
//
//    @JavascriptInterface
//    public void logEvent(String json) {
//        try {
//            Map<String, String> map = new HashMap<>();
//            map.put("type", "log_event");
//            map.put("data", json);
//            WebViewManager.getInstance().setData(map);
//        } catch (Exception e) {
//            WiseLog.e(e);
//        }
//    }
//
//    @JavascriptInterface
//    public void logConversion(String json) {
//        try {
//            Map<String, String> map = new HashMap<>();
//            map.put("type", "log_conversion");
//            map.put("data", json);
//            WebViewManager.getInstance().setData(map);
//        } catch (Exception e) {
//            WiseLog.e(e);
//        }
//    }
//
//    @JavascriptInterface
//    public void logPurchase(String json) {
//        try {
//            Map<String, String> map = new HashMap<>();
//            map.put("type", "log_purchase");
//            map.put("data", json);
//            WebViewManager.getInstance().setData(map);
//        } catch (Exception e) {
//            WiseLog.e(e);
//        }
//    }
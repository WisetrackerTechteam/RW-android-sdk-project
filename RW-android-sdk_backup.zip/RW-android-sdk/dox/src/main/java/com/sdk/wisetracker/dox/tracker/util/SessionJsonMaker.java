package com.sdk.wisetracker.dox.tracker.util;

import android.util.Pair;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.model.Session;
import com.sdk.wisetracker.dox.tracker.manager.DoxManager;

import java.util.List;

/**
 * DOX 사용 세션 키 정의
 * 정의된 Key 값 만 세션 데이터에 포함되어 전송
 */
public class SessionJsonMaker {

    private static String[] session_key = {
            "advtId",
            "device_uuid",
            "vendor_id",
            "uuid",
            "sid",
            "isVisitNew",
            "userId",
            "lng",
            "cntr",
            "tz",
            "os",
            "osvr",
            "sr",
            "phone",
            "gps",
            "cari",
            "isWifi",
            "inch",
            "plat",
            "buildMode",
            "aidChange",
            "advtFlag",
            "dSource",
            "apVr",
            "pkg",
            "_wthst",
            "_wtno",
            "_accessToken",
            "_wtDebug",
            "sdk_version"
    };

    public static JsonObject getSessionString(Session session) {

        try {

            if (session == null) {
                return null;
            }

            String sessionString = new Gson().toJson(session);
            JsonElement rawElement = new JsonParser().parse(sessionString);
            JsonObject sessionJsonObject = rawElement.getAsJsonObject();
            return getUnusedSessionJsonObject(sessionJsonObject);

        } catch (Exception e) {
            WiseLog.e(e);
        }

        String sessionString = new Gson().toJson(session);
        JsonElement rawElement = new JsonParser().parse(sessionString);
        return rawElement.getAsJsonObject();

    }

    private static JsonObject getUnusedSessionJsonObject(JsonObject jsonObject) {

        try {

            JsonObject removedSessionJsonObject = new JsonObject();

            for (int i = 0; i < session_key.length; i++) {
                if (!jsonObject.has(session_key[i])) {
                    continue;
                }
                if (jsonObject.get(session_key[i]).isJsonObject()) {
                    removedSessionJsonObject.add(session_key[i], jsonObject.get(session_key[i]));
                    continue;
                }
                JsonPrimitive primitive = jsonObject.get(session_key[i]).getAsJsonPrimitive();
                if (primitive.isBoolean()) {
                    removedSessionJsonObject.addProperty(session_key[i], jsonObject.get(session_key[i]).getAsBoolean());
                } else if (primitive.isNumber()) {
                    removedSessionJsonObject.addProperty(session_key[i], jsonObject.get(session_key[i]).getAsNumber());
                } else if (primitive.isString()) {
                    removedSessionJsonObject.addProperty(session_key[i], jsonObject.get(session_key[i]).getAsString());
                }
            }

            return getCustomKeySessionJsonObject(removedSessionJsonObject);

        } catch (Exception e) {
            WiseLog.e(e);
        }

        return null;

    }

    private static JsonObject getCustomKeySessionJsonObject(JsonObject jsonObject) {

        try {

            List<Pair<String, String>> customKeyList = DoxManager.getInstance().getCustomList();
            if (customKeyList == null || customKeyList.isEmpty()) {
                return jsonObject;
            }

            for (int i = 0; i < customKeyList.size(); i++) {

                Pair<String, String> pair = customKeyList.get(i);
                if (!jsonObject.has(pair.first)) {
                    continue;
                }

                JsonPrimitive primitive = jsonObject.get(pair.first).getAsJsonPrimitive();
                if (primitive.isBoolean()) {
                    Boolean value = jsonObject.get(session_key[i]).getAsBoolean();
                    jsonObject.addProperty(pair.second, value);
                } else if (primitive.isNumber()) {
                    Number value = jsonObject.get(session_key[i]).getAsNumber();
                    jsonObject.addProperty(pair.second, value);
                } else if (primitive.isString()) {
                    String value = jsonObject.get(session_key[i]).getAsString();
                    jsonObject.addProperty(pair.second, value);
                }

                jsonObject.remove(pair.first);

            }

            return jsonObject;

        } catch (Exception e) {
            WiseLog.e(e);
        }

        return jsonObject;

    }

}

/*

public JsonElement getSessionString(Session session) {

        try {

            String sessionJsonString = new Gson().toJson(session);
            if (TextUtils.isEmpty(sessionJsonString)) {
                return null;
            }

            JsonObject sessionJsonObject = new JsonParser().parse(sessionJsonString).getAsJsonObject();
            String newSessionJsonString = jsonIterator(new JsonObject(), sessionJsonObject.entrySet().iterator());
            if (TextUtils.isEmpty(newSessionJsonString)) {
                return null;
            }

            JsonObject newSessionJsonObject = new JsonParser().parse(newSessionJsonString).getAsJsonObject();
            return getUnusedSessionJsonObject(newSessionJsonObject);

        } catch (Exception e) {
            WiseLog.e(e);
        }

        return null;

    }

    private String jsonIterator(JsonObject newJsonObject, Iterator iterator) {

        try {

            while (iterator.hasNext()) {

                Map.Entry<String, JsonElement> map = (Map.Entry<String, JsonElement>) iterator.next();
                JsonElement jsonElement = map.getValue();
                if (jsonElement.isJsonObject()) {
                    JsonObject jsonObject = jsonElement.getAsJsonObject();
                    jsonIterator(newJsonObject, jsonObject.entrySet().iterator());
                } else {
                    newJsonObject.add(map.getKey(), map.getValue());
                }

            }

            return newJsonObject.toString();

        } catch (Exception e) {
            WiseLog.e(e);
        }

        return null;

    }

 */

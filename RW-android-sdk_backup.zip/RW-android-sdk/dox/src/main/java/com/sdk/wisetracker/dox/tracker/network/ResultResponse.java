package com.sdk.wisetracker.dox.tracker.network;

import com.google.gson.annotations.SerializedName;

public class ResultResponse {

    private @SerializedName("code") String code = null;
    private @SerializedName("msg") String message = null;
    private @SerializedName("result") boolean result = false;
    private @SerializedName("time") long connectionTime = 0;

    public boolean isResult() {
        return result;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public long getConnectionTime() {
        return connectionTime;
    }

}


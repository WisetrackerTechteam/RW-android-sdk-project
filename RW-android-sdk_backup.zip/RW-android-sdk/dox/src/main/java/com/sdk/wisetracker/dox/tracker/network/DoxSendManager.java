package com.sdk.wisetracker.dox.tracker.network;

import android.annotation.SuppressLint;

import com.google.gson.JsonArray;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.common.log.WiseValidation;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.network.type.HeaderType;
import com.sdk.wisetracker.dox.tracker.manager.DoxManager;
import com.sdk.wisetracker.dox.tracker.model.Result;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import okhttp3.ResponseBody;

/**
 * DOX 이벤트 데이터 전송 class
 */
public class DoxSendManager {

    private static boolean isProcess = false;

    @SuppressLint("CheckResult")
    public static void sendEventTransaction() {

        // 진행중
        if (isProcess) {
            return;
        }
        isProcess = true;

        Observable
                // event 발생 후 30초 동안 모인 데이터 지연 전송
                .timer(30, TimeUnit.SECONDS)
                .flatMap(new Function<Long, ObservableSource<ResponseBody>>() {
                    @Override
                    public ObservableSource<ResponseBody> apply(Long aLong) {
                        DoxApi api = DoxRetrofit.getInstance().getBaseApi(DoxApi.class, HeaderType.BASE);
                        return api.sendTransaction(getDoxResultString());
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<ResponseBody>() {
                    @Override
                    public void accept(ResponseBody result) {
                        try {
                            WiseLog.d("DOX response message -> " + result.string());
                        } catch (Exception e) {
                            WiseLog.d("DOX SEND ERROR");
                            WiseLog.e(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) {
                        isProcess = false;
                        DoxManager.getInstance().clearResultList();
                        WiseLog.e(throwable);
                    }
                }, new Action() {
                    @Override
                    public void run() {
                        // 초기화
                        isProcess = false;
                        DoxManager.getInstance().clearResultList();
                        SessionDataManager.getInstance().updateSessionAfterTransaction();
                    }
                });

    }

    private static String getDoxResultString() {
        List<Result> resultList = DoxManager.getInstance().getResultList();
        if (resultList == null || resultList.isEmpty()) {
            return null;
        }
        JsonArray jsonArray = new JsonArray();
        for (Result result : resultList) {
            jsonArray.add(result.getResultObject());
        }
        String result = jsonArray.toString();
        WiseValidation.doxSdkValidation(result);
        WiseLog.d("DOX_JSON_STRING -> " + result);
        return result;
    }

}
package com.sdk.wisetracker.dox.tracker.model;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.data.model.Session;
import com.sdk.wisetracker.dox.open.model.XConversion;
import com.sdk.wisetracker.dox.open.model.XEvent;
import com.sdk.wisetracker.dox.open.model.XIdentify;
import com.sdk.wisetracker.dox.open.model.XPurchase;
import com.sdk.wisetracker.dox.tracker.util.SessionJsonMaker;

import java.util.Map;

/**
 * 전송 데이터 모델 관리 class
 */
public class Result {

    private long sequenceCount = 0;
    private long eventCount = 0;
    private long eventTime = 0;
    private Session session = null;
    private Map<String, String> groupsMap = null;
    private XIdentify groupProperty = null;
    private XIdentify userProperty = null;
    private XEvent event = null;
    private XConversion conversion = null;
    private XPurchase purchase = null;

    public void setSequenceCount(long sequenceCount) {
        this.sequenceCount = sequenceCount;
    }

    public void setEventCount(long eventCount) {
        this.eventCount = eventCount;
    }

    public void setEventTime(long eventTime) {
        this.eventTime = eventTime;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public void setGroupsMap(Map<String, String> groupsMap) {
        this.groupsMap = groupsMap;
    }

    public void setGroupProperty(XIdentify groupProperty) {
        this.groupProperty = groupProperty;
    }

    public void setUserProperty(XIdentify userProperty) {
        this.userProperty = userProperty;
    }

    public void setEvent(XEvent event) {
        this.event = event;
    }

    public void setConversion(XConversion conversion) {
        this.conversion = conversion;
    }

    public void setPurchase(XPurchase purchase) {
        this.purchase = purchase;
    }

    // 변수에 들어 있는 데이터를 json 형태로 변환하여 전송
    public JsonObject getResultObject() {

        JsonObject resultObject = new JsonObject();

        resultObject.addProperty("sequence", sequenceCount);
        resultObject.addProperty("eventId", eventCount);
        resultObject.addProperty("eventTime", eventTime);

        if (session != null) {
            resultObject.add("session", SessionJsonMaker.getSessionString(session));
        }

        if (groupsMap != null) {
            JsonElement jsonElement = new JsonParser().parse(new Gson().toJson(groupsMap));
            resultObject.add("groups", jsonElement);
        }
        if (groupProperty != null) {
            resultObject.add("groupproperties", groupProperty.getJsonElement());
        }
        if (userProperty != null) {
            resultObject.add("userproperties", userProperty.getJsonElement());
        }
        if (event != null) {
            resultObject.add("events", event.getJsonElement());
        }
        if (conversion != null) {
            resultObject.add("conversion", conversion.getJsonElement());
        }
        if (purchase != null) {
            resultObject.add("revenue", purchase.getJsonElement());
        }

        return resultObject;

    }

}

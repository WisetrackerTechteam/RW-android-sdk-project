package com.sdk.wisetracker.dox.tracker.manager;

import android.content.Context;
import android.text.TextUtils;
import android.util.Pair;
import android.webkit.WebView;

import com.sdk.wisetracker.base.tracker.common.WisetrackerDatabase;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.dox.BuildConfig;
import com.sdk.wisetracker.dox.R;
import com.sdk.wisetracker.dox.open.model.XConversion;
import com.sdk.wisetracker.dox.open.model.XEvent;
import com.sdk.wisetracker.dox.open.model.XIdentify;
import com.sdk.wisetracker.dox.open.model.XPurchase;
import com.sdk.wisetracker.dox.tracker.model.Result;
import com.sdk.wisetracker.dox.tracker.model.XGroupProperty;
import com.sdk.wisetracker.dox.tracker.network.DoxSendManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * DOX 이벤트 발생시 처리 manager
 */
public class DoxManager {

    private static DoxManager instance = null;
    public static final String IDENTIFY_EVENT_COUNT = "IDENTIFY_EVENT_COUNT";
    public static final String EVENT_COUNT = "EVENT_COUNT";
    public static final String SEQUENCE_COUNT = "SEQUENCE_COUNT";
    private List<Result> resultList = new ArrayList<>();

    public static DoxManager getInstance() {
        if (instance == null) {
            instance = new DoxManager();
        }
        return instance;
    }

    public DoxManager() {
        // set sdk version
        SessionDataManager.getInstance().setSdkVersion(new Pair<>("DOX", BuildConfig.VERSION_NAME));
    }

    public List<Result> getResultList() {
        return resultList;
    }

    public void clearResultList() {
        resultList.clear();
    }

    public Result getBaseResult() {
        Result result = new Result();
        result.setEventTime(System.currentTimeMillis());
        result.setSession(SessionDataManager.getInstance().getUpdateSessionData());
        result.setSequenceCount(getSequenceCount());
        return result;
    }

    public void setGroupIdentify(XGroupProperty xGroupProperty) {
        Result result = getBaseResult();
        result.setEventCount(getIdentifyEventCount());
        result.setGroupProperty(xGroupProperty.getGroupIdentify());
        result.setGroupsMap(xGroupProperty.getGroupsMap());
        resultList.add(result);
        DoxSendManager.sendEventTransaction();
    }

    public void setUserIdentify(XIdentify identify) {
        Result result = getBaseResult();
        result.setEventCount(getIdentifyEventCount());
        result.setUserProperty(identify);
        resultList.add(result);
        DoxSendManager.sendEventTransaction();
    }

    public void setLogEvent(XEvent event) {
        Result result = getBaseResult();
        result.setEventCount(getEventCount());
        result.setEvent(event);
        resultList.add(result);
        DoxSendManager.sendEventTransaction();
    }

    public void setLogConversion(XConversion conversion) {
        Result result = getBaseResult();
        result.setEventCount(getEventCount());
        result.setConversion(conversion);
        resultList.add(result);
        DoxSendManager.sendEventTransaction();
    }

    public void setLogPurchase(XPurchase purchase) {
        Result result = getBaseResult();
        result.setEventCount(getEventCount());
        result.setPurchase(purchase);
        resultList.add(result);
        DoxSendManager.sendEventTransaction();
    }

    private long getSequenceCount() {
        try {
            long count = WisetrackerDatabase.getLongValue(SEQUENCE_COUNT);
            WisetrackerDatabase.setDatabase(SEQUENCE_COUNT, ++count);
            return count;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return 0;
    }

    private long getIdentifyEventCount() {
        try {
            long count = WisetrackerDatabase.getLongValue(IDENTIFY_EVENT_COUNT);
            WisetrackerDatabase.setDatabase(IDENTIFY_EVENT_COUNT, ++count);
            return count;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return 0;
    }

    private long getEventCount() {
        try {
            long count = WisetrackerDatabase.getLongValue(EVENT_COUNT);
            WisetrackerDatabase.setDatabase(EVENT_COUNT, ++count);
            return count;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return 0;
    }

    public List<Pair<String, String>> getCustomList() {
        try {
            Context context = InitializeManager.applicationContext;
            if (context == null) {
                return null;
            }
            List<CharSequence> customKeyList = new ArrayList<>(Arrays.asList(context.getResources().getTextArray(R.array.customKeyList)));
            if (customKeyList.isEmpty()) {
                return null;
            }
            List<Pair<String, String>> pairList = new ArrayList<>();
            for (CharSequence charSequence : customKeyList) {
                if (charSequence.toString().contains("#")) {
                    String[] splitString = charSequence.toString().split("#");
                    if (TextUtils.isEmpty(splitString[0]) || TextUtils.isEmpty(splitString[1])) {
                        continue;
                    }
                    pairList.add(new Pair<>(splitString[0], splitString[1]));
                }
            }
            return pairList;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

    public void setWebView(WebView webView) {
        DoxWebViewManager.getInstance().setWebView(webView);
    }

    public void injectJavascript(WebView webView) {
        DoxWebViewManager.getInstance().injectJavascript(webView);
    }

}

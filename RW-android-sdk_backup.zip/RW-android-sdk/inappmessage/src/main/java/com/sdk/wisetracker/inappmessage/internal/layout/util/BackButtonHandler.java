package com.sdk.wisetracker.inappmessage.internal.layout.util;

import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import androidx.annotation.Nullable;

public class BackButtonHandler {
    private ViewGroup viewGroup;
    private OnClickListener listener;

    public BackButtonHandler(ViewGroup viewGroup, OnClickListener listener) {
        this.viewGroup = viewGroup;
        this.listener = listener;
    }

    @Nullable
    public Boolean dispatchKeyEvent(KeyEvent event) {
        if (event != null && event.getKeyCode() == 4 && event.getAction() == 1) {
            if (this.listener != null) {
                this.listener.onClick(this.viewGroup);
                return true;
            } else {
                return false;
            }
        } else {
            return null;
        }
    }
}

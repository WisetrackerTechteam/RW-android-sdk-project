package com.sdk.wisetracker.inappmessage.internal.layout;


import android.view.View.OnClickListener;

public interface BackButtonLayout {
    void setDismissListener(OnClickListener var1);
}

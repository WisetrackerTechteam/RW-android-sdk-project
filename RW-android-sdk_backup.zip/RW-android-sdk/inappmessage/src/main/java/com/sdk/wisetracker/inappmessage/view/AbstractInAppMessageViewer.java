package com.sdk.wisetracker.inappmessage.view;

import android.app.Activity;

import com.google.gson.JsonObject;

public interface AbstractInAppMessageViewer {

    public void onImpressionEvent(JsonObject message);
    public void onClickEvent(JsonObject message);

}

package com.sdk.wisetracker.inappmessage;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.room.util.StringUtil;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.InAppMessageDataManager;
import com.sdk.wisetracker.inappmessage.network.InAppMessageSendManager;
import com.sdk.wisetracker.inappmessage.view.CardViewTest;

public class InAppMessageBroadcastReceiver extends BroadcastReceiver {
    private Activity activity;
    public InAppMessageBroadcastReceiver(Activity activity) {
        this.activity = activity;
    }

    private String previousMessageKey = "";
    @Override
    public void onReceive(Context context, Intent intent) {
        try{
            JsonObject _json = this.getMessageDataFromIntent(intent);
            WiseLog.d("_json: " + _json);
            if( _json != null && _json.size() > 0 ){
                // 1. 동일한 메시지가 연속으로 중복해서 올 수 있으므로, 가장 먼저 mk 값을 이전 값에 설정함.
                String currentMessageKey = _json.get("mk").getAsString();
                if(!previousMessageKey.equals(currentMessageKey)){
                    JsonObject frequency = _json.getAsJsonObject("frequency");
                    frequency.addProperty("viewTime",System.currentTimeMillis());

                    // 1. 현재 수신한 mk값을 alreadySeenId로 저장.
                    if( InAppMessageDataManager.getInstance().displayInAppMessageId(currentMessageKey, frequency) ) {

                        // 2. 메시지 노출 데이터를 서버로 전송
                        InAppMessageSendManager.getInstance().sendImpressionDataToServer(currentMessageKey);

                        // 3. 메시지 노출 데이터를 Activity 로 전달.
                        // TODO : 메시지 노출 로직 추가
                        CardViewTest test = new CardViewTest();
                        test.onImpressionEvent(_json);

                        WiseLog.d("11111");
//                        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//                        ComponentName cn = am.getRunningTasks(1).get(0).topActivity;
//                        String activityName = cn.getClassName();
//                        WiseLog.d("cn: " + activityName);
//                        int id = context.getResources().getIdentifier(activityName, "id", context.getPackageName());
//                        WiseLog.d("id: " + id);
//
//                        View v = View.inflate(context, R.layout.card, null);

                        // inflate the layout of the popup window
//                        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//                        View popupView = inflater.inflate(R.layout.card, null);

//                        activity.startActivity(new Intent("com.sdk.wisetracker.inappmessage.view.CardViewTest"));
                        Intent test2 = new Intent(context, CardViewTest.class);
                        Bundle b = new Bundle();
                        b.putString("impressionEvent", _json.toString());
                        test2.putExtras(b);
                        activity.startActivity(test2);

                        // create the popup window
//                        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
//                        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
//                        boolean focusable = true; // lets taps outside the popup also dismiss it
//                        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

                        // show the popup window
                        // which view you pass in doesn't matter, it is only used for the window tolken
//                        popupWindow.showAtLocation(activity.getWindow().getDecorView(), Gravity.CENTER, 0, 0);

                        // dismiss the popup window when touched
//                        popupView.setOnTouchListener(new View.OnTouchListener() {
//                            @Override
//                            public boolean onTouch(View v, MotionEvent event) {
//                                popupWindow.dismiss();
//                                return true;
//                            }
//                        });

//                        View view = cn.getWindow().getDecorView().getRootView(); // returns base view of the fragment
//                        if (view != null && view instanceof ViewGroup) {
//                            WiseLog.d("2222");
//                            ViewGroup viewGroup = (ViewGroup) view;
//                            View popup = View.inflate(viewGroup.getContext(), R.layout.card, viewGroup);
//                        }

                        InAppMessageSendManager.getInstance().sendClickDataToServer(currentMessageKey, frequency);
                        // FIXME 테스트 상황에서만 주석처리하세요, 실제 환경에서는 반드시 주석 해제
                        // previousMessageKey = currentMessageKey;
                    } else {
                        WiseLog.d("The message is not displayed because the message exposure frequency is exceeded. ( message key : " + currentMessageKey + ")" );
                    }
                }else{
                    WiseLog.d("It is possible that the message has already been received and exposed.( message key : " + currentMessageKey + ")" );
                }
            }
        }catch(Exception e){
            WiseLog.e(e);
            e.printStackTrace();
        }
    }

    /**
     * Intent 에서 message 데이터를 추출하는 함수
     **/
    private JsonObject getMessageDataFromIntent(Intent intent) throws Exception{
        JsonObject message = null;
        try{
            if( intent != null && intent.hasExtra("message")){
                String messageStr = intent.getStringExtra("message");
                if( messageStr != null && !messageStr.equals("")){
                    JsonParser parser = new JsonParser();
                    message = (JsonObject)parser.parse(messageStr);
                }
            }
        }catch(Exception e){
            WiseLog.e(e);
        }
        return message;
    }

}

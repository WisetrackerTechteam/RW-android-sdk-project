package com.sdk.wisetracker.inappmessage.view;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.inappmessage.R;
import com.sdk.wisetracker.inappmessage.network.InAppMessageSendManager;

public class CardViewTest extends Activity implements AbstractInAppMessageViewer {

  private Gson gson = new Gson();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    requestWindowFeature(Window.FEATURE_NO_TITLE);
    setContentView(R.layout.card);

    Intent intent = getIntent();
    WiseLog.d("intent.extra: " + intent.getStringExtra("impressionEvent"));
    JsonObject impressionEvent = gson.fromJson(intent.getStringExtra("impressionEvent"), JsonObject.class);
    String imgUrl = impressionEvent.getAsJsonObject("view").get("imgUrl").getAsString();
    WiseLog.d("impressionEvent.view.imgUrl: " + imgUrl);

  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
  }

  @Override
  protected void onResume() {
    super.onResume();
  }

  @Override
  public void onImpressionEvent(JsonObject message) {
    WiseLog.d("message: " + message);
  }

  @Override
  public void onClickEvent(JsonObject message) {

  }
}

package com.sdk.wisetracker.inappmessage.network;

import com.google.gson.JsonObject;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.InAppMessageDataManager;
import com.sdk.wisetracker.new_dot.open.DOT;

import java.util.HashMap;
import java.util.Map;

public class InAppMessageSendManager {

    private static InAppMessageSendManager instance = null;
    public static InAppMessageSendManager getInstance() {
        if (instance == null) {
            instance = new InAppMessageSendManager();
        }
        return instance;
    }

    // 1. impression 데이터 전송  ( logEvent )
    public void sendImpressionDataToServer(String newMessageId){
        try{

            // logEvent 생성 & send To Server impression data
            Map<String, Object> eventMap = new HashMap<>();
            eventMap.put("event", "w_inappmsg_impression");
            eventMap.put("inamId", newMessageId);
            DOT.logEvent(eventMap);

        }catch(Exception e){
            WiseLog.e(e);
        }
    }

    // 2. 클릭 데이터를 서버로 전송 ( logEvent )
    public void sendClickDataToServer(String newInAppMessageId, JsonObject frequency){
        try{

            // 1. update session data
            InAppMessageDataManager.getInstance().updateInAppMessageId(newInAppMessageId ,frequency);

            // 2. logEvent 생성 & send To Server click data
            Map<String, Object> eventMap = new HashMap<>();
            eventMap.put("event", "w_inappmsg_click");
            eventMap.put("inamId", newInAppMessageId);
            DOT.logEvent(eventMap);

        }catch(Exception e){
            WiseLog.e(e);
        }
    }

}

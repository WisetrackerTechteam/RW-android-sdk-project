package com.sdk.wisetracker.inappmessage.internal.layout.util;

import android.view.View;
import android.view.View.MeasureSpec;
import com.sdk.wisetracker.inappmessage.internal.Logging;

public class MeasureUtils {
    public MeasureUtils() {
    }

    public static void measureAtMost(View child, int width, int height) {
        measure(child, width, height, -2147483648, -2147483648);
    }

    public static void measureExactly(View child, int width, int height) {
        measure(child, width, height, 1073741824, 1073741824);
    }

    public static void measureFullWidth(View child, int width, int height) {
        measure(child, width, height, 1073741824, -2147483648);
    }

    public static void measureFullHeight(View child, int width, int height) {
        measure(child, width, height, -2147483648, 1073741824);
    }

    private static void measure(View child, int width, int height, int widthSpec, int heightSpec) {
        Logging.logdPair("\tdesired (w,h)", (float)child.getMeasuredWidth(), (float)child.getMeasuredHeight());
        if (child.getVisibility() == 8) {
            width = 0;
            height = 0;
        }

        child.measure(MeasureSpec.makeMeasureSpec(width, widthSpec), MeasureSpec.makeMeasureSpec(height, heightSpec));
        Logging.logdPair("\tactual (w,h)", (float)child.getMeasuredWidth(), (float)child.getMeasuredHeight());
    }
}

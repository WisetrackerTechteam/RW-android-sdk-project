package com.sdk.wisetracker.inappmessage.internal.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View.OnClickListener;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;

import com.sdk.wisetracker.inappmessage.internal.layout.util.BackButtonHandler;

public class DOTiamCardView extends CardView implements BackButtonLayout {
    private BackButtonHandler mBackHandler;

    public DOTiamCardView(Context context) {
        super(context);
    }

    public DOTiamCardView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DOTiamCardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setDismissListener(OnClickListener listener) {
        this.mBackHandler = new BackButtonHandler(this, listener);
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        Boolean handled = this.mBackHandler.dispatchKeyEvent(event);
        return handled != null ? handled : super.dispatchKeyEvent(event);
    }
}
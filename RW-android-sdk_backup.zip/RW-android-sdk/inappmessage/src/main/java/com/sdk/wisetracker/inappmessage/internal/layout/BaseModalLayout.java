package com.sdk.wisetracker.inappmessage.internal.layout;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.sdk.wisetracker.inappmessage.R.styleable;
import com.sdk.wisetracker.inappmessage.internal.Logging;
import java.util.ArrayList;
import java.util.List;

public class BaseModalLayout extends FrameLayout{
    private static final float DEFAULT_MAX_WIDTH_PCT = -1.0F;
    private static final float DEFAULT_MAX_HEIGHT_PCT = -1.0F;
    private float mMaxWidthPct;
    private float mMaxHeightPct;
    private DisplayMetrics mDisplay;
    private List<View> mVisibleChildren = new ArrayList();

    public BaseModalLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, styleable.ModalLayout, 0, 0);

        try {
            this.mMaxWidthPct = a.getFloat(styleable.ModalLayout_maxWidthPct, -1.0F);
            this.mMaxHeightPct = a.getFloat(styleable.ModalLayout_maxHeightPct, -1.0F);
        } finally {
            a.recycle();
        }

        this.mDisplay = context.getResources().getDisplayMetrics();
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        Logging.logdHeader("BEGIN LAYOUT");
        Logging.logd("onLayout: l: " + left + ", t: " + top + ", r: " + right + ", b: " + bottom);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        Logging.logdHeader("BEGIN MEASURE");
        Logging.logdPair("Display", (float)this.getDisplayMetrics().widthPixels, (float)this.getDisplayMetrics().heightPixels);
        this.mVisibleChildren.clear();

        for(int i = 0; i < this.getChildCount(); ++i) {
            View child = this.getChildAt(i);
            if (child.getVisibility() != 8) {
                this.mVisibleChildren.add(child);
            } else {
                Logging.logdNumber("Skipping GONE child", (float)i);
            }
        }

    }

    protected float getMaxWidthPct() {
        return this.mMaxWidthPct;
    }

    protected float getMaxHeightPct() {
        return this.mMaxHeightPct;
    }

    protected DisplayMetrics getDisplayMetrics() {
        return this.mDisplay;
    }

    protected List<View> getVisibleChildren() {
        return this.mVisibleChildren;
    }

    protected int calculateBaseWidth(int widthMeasureSpec) {
        int baseLayoutWidth;
        if (this.getMaxWidthPct() > 0.0F) {
            Logging.logd("Width: restrict by pct");
            baseLayoutWidth = this.roundToNearest((int)((float)this.getDisplayMetrics().widthPixels * this.getMaxWidthPct()), 4);
        } else {
            Logging.logd("Width: restrict by spec");
            baseLayoutWidth = MeasureSpec.getSize(widthMeasureSpec);
        }

        return baseLayoutWidth;
    }

    protected int calculateBaseHeight(int heightMeasureSpec) {
        int baseLayoutHeight;
        if (this.getMaxHeightPct() > 0.0F) {
            Logging.logd("Height: restrict by pct");
            baseLayoutHeight = this.roundToNearest((int)((float)this.getDisplayMetrics().heightPixels * this.getMaxHeightPct()), 4);
        } else {
            Logging.logd("Height: restrict by spec");
            baseLayoutHeight = MeasureSpec.getSize(heightMeasureSpec);
        }

        return baseLayoutHeight;
    }

    protected void measureChildWithMargins(View child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
        Logging.logdPair("\tdesired (w,h)", (float)child.getMeasuredWidth(), (float)child.getMeasuredHeight());
        super.measureChildWithMargins(child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed);
        Logging.logdPair("\tactual  (w,h)", (float)child.getMeasuredWidth(), (float)child.getMeasuredHeight());
    }

    protected void layoutChild(View view, int left, int top) {
        this.layoutChild(view, left, top, left + this.getDesiredWidth(view), top + this.getDesiredHeight(view));
    }

    protected void layoutChild(View view, int left, int top, int right, int bottom) {
        Logging.logdPair("\tleft, right", (float)left, (float)right);
        Logging.logdPair("\ttop, bottom", (float)top, (float)bottom);
        view.layout(left, top, right, bottom);
    }

    @NonNull
    protected View findChildById(@IdRes int id) {
        View v = this.findViewById(id);
        if (v == null) {
            throw new IllegalStateException("No such child: " + id);
        } else {
            return v;
        }
    }

    protected int getHeightWithMargins(View child) {
        if (child.getVisibility() == 8) {
            return 0;
        } else {
            LayoutParams params = this.getLayoutParams(child);
            return this.getDesiredHeight(child) + params.topMargin + params.bottomMargin;
        }
    }

    protected int getMarginBottom(View child) {
        return child.getVisibility() == 8 ? 0 : this.getLayoutParams(child).bottomMargin;
    }

    protected int getMarginTop(View child) {
        return child.getVisibility() == 8 ? 0 : this.getLayoutParams(child).topMargin;
    }

    protected int getWidthWithMargins(View child) {
        if (child.getVisibility() == 8) {
            return 0;
        } else {
            LayoutParams params = this.getLayoutParams(child);
            return this.getDesiredWidth(child) + params.leftMargin + params.rightMargin;
        }
    }

    protected int getDesiredWidth(View child) {
        return child.getVisibility() == 8 ? 0 : child.getMeasuredWidth();
    }

    protected int getDesiredHeight(View child) {
        return child.getVisibility() == 8 ? 0 : child.getMeasuredHeight();
    }

    protected LayoutParams getLayoutParams(View child) {
        return (LayoutParams)child.getLayoutParams();
    }

    protected int roundToNearest(int num, int unit) {
        return unit * Math.round((float)num / (float)unit);
    }

    protected int dpToPixels(int dp) {
        return (int)Math.floor((double)TypedValue.applyDimension(1, (float)dp, this.mDisplay));
    }
}

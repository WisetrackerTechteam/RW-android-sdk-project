package com.sdk.wisetracker.new_dot.tracker.init;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;
import com.sdk.wisetracker.new_dot.open.DOT;

/**
 * 앱 실행시 SDK 자동 초기화 설정 class
 */
@SuppressLint("NewApi")
public class ActivityDetector implements Application.ActivityLifecycleCallbacks {

    private int refs = 0;
    private boolean isFirst = true;
    public void setIsFirst(boolean flag){
        this.isFirst = flag;
    }
    private static ActivityDetector Instance = null;

    public static ActivityDetector getInstance() {
        if (Instance == null) {
            Instance = new ActivityDetector();
        }
        return Instance;
    }

    public void setApplication(Application application) {
        application.registerActivityLifecycleCallbacks(this);
    }

    public boolean isForeground() {
        return refs > 0;
    }

    public boolean isBackground() {
        return refs == 0;
    }

    // 첫번째 Activity 로드시 SDK 초기화 수행
    @Override
    public void onActivityStarted(Activity activity) {
        WiseLog.d("on activity started by ActivityDetector : " + activity.toString());
        WiseLog.d("reference count by ActivityDetector : " + refs);
        if (++refs == 1) {
            if (isFirst) {
                // Facebook AppLink data 사용 여부 설정
                if( activity.getApplicationContext().getResources().getText(com.sdk.wisetracker.base.R.string.useFacebookAppLinkData) != null ){
                    InitializeManager.useFacebookAppLinkData = (String)activity.getApplicationContext().getResources().getText(com.sdk.wisetracker.base.R.string.useFacebookAppLinkData);
                    if( InitializeManager.useFacebookAppLinkData != null && InitializeManager.useFacebookAppLinkData.equals("Y")){
                        // 최초 데이터 전송전 Facebook Deferred Link를 기다려야 하는지 플래그 설정.
                        try {
                            Class.forName( "com.facebook.applinks.AppLinkData" );
                            InitializeManager.waitingForFbDeferred = true;
                        } catch( ClassNotFoundException e ) {
                        }
                    }
                }
                //DOT.init(activity);
                isFirst = false;
            }
        }
    }

    // 마지막 Activity onStop() 호출시 페이지 데이터 전송
    // 백그라운드 진입시 처리 위해 적용
    @Override
    public void onActivityStopped(Activity activity) {
        WiseLog.d("on activity stopped : " + activity.toString());
        WiseLog.d("reference count : " + refs);
        if (--refs == 0) {
            DOT.onStopPage();
            WiseLog.d("refs count is 0");
        }
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        WiseLog.d("on activity created : " + activity.toString());
    }

    @Override
    public void onActivityResumed(Activity activity) {
        WiseLog.d("on activity resumed : " + activity.toString());
    }

    @Override
    public void onActivityPaused(Activity activity) {
        WiseLog.d("on activity paused : " + activity.toString());
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        //WiseLog.d("on activity save instance state : " + activity.toString());
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        WiseLog.d("on activity destroyed : " + activity.toString());
    }
}
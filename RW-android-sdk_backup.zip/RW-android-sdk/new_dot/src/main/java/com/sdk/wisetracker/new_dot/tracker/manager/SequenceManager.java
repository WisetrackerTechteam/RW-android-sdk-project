package com.sdk.wisetracker.new_dot.tracker.manager;

import android.app.Application;
import android.content.Context;

import com.sdk.wisetracker.base.tracker.common.WisetrackerDatabase;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

/**
 * 페이지 전환시 sequence 체크 class
 */
public class SequenceManager {

    private static SequenceManager instance = null;
    private Context context = null;
    private int sequence;

    public static SequenceManager getInstance() {
        if (instance == null) {
            instance = new SequenceManager();
        }
        return instance;
    }

    public SequenceManager() {
        sequence = WisetrackerDatabase.getIntValue("page_sequence");
    }

    // 시퀀스 설정
    // 페이지 전환시 전달 받은 context 정보로 페이지 전환 여부 체크
    public void setSequence(Context context) {

        try {

            if (context == null) {
                return;
            }

            if (context instanceof Application) {
                WiseLog.d("application context");
                return;
            }

            if (this.context == null || this.context != context) {
                sequence++;
                this.context = context;
                WiseLog.d("page_sequence : " + sequence);
                WisetrackerDatabase.setDatabase("page_sequence", sequence);
            }

        } catch (Exception e) {
            WiseLog.e(e);
        }

    }

    public int getSequence() {
        return sequence;
    }

}

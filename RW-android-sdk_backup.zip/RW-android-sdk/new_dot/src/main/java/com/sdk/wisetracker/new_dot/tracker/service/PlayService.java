package com.sdk.wisetracker.new_dot.tracker.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.data.model.Session;
import com.sdk.wisetracker.new_dot.tracker.manager.DotManager;
import com.sdk.wisetracker.new_dot.tracker.manager.SequenceManager;

import java.util.Timer;
import java.util.TimerTask;

/**
 * 체류 시간 측정 백그라운드 service
 */
public class PlayService extends Service {

    private static final int DEFAULT_INTERVAL = 15;
    public static final String GAME_ACTION = "GameAction";
    private Timer timer = null;
    private long lastSendTime = 0;
    private long periodToMillis = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        WiseLog.d("game service create");
    }

    // 체류 시간 측정 API 호출시 스케쥴러 등록
    // 전달 받은 측정 시간에 따라 동작 (기본 15분)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || TextUtils.isEmpty(intent.getAction())) {
            return START_NOT_STICKY;
        }
        if (!intent.getAction().equals(GAME_ACTION)) {
            return START_NOT_STICKY;
        }
        if (timer == null) {
            WiseLog.d("game service action");
            int period = intent.getIntExtra(PlayService.class.getSimpleName(), DEFAULT_INTERVAL);
            if (period == 0) {
                period = DEFAULT_INTERVAL;
            }
            WiseLog.d("game period time : " + period + " minute");
            lastSendTime = System.currentTimeMillis();
            periodToMillis = period * 1000 * 60;
            timer = new Timer();
            timer.schedule(timerTask, periodToMillis, periodToMillis);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        WiseLog.d("game service destroy");
        if (timer != null) {
            timer.cancel();
        }
        sendIntervalPage(false);
        super.onDestroy();
    }

    // 전송 스케쥴러
    private TimerTask timerTask = new TimerTask() {
        @Override
        public void run() {
            sendIntervalPage(true);
        }
    };

    // 측정 체류 시간 경과시 또는 측정 체류 시간 종료시 페이지 데이터 전송
    private void sendIntervalPage(boolean isTimerTask) {

        try {

            WiseLog.d("send game page by isTimerTask -> " + isTimerTask);

            Session session = SessionDataManager.getInstance().getUpdateSessionData();
            JsonObject sessionObject = new JsonParser().parse(new Gson().toJson(session)).getAsJsonObject();
            //sessionObject.addProperty("pageKey", SequenceManager.getInstance().getSequence());

            JsonObject pagesObject = new JsonObject();
            if (isTimerTask) {
                WiseLog.d("game vs -> " + periodToMillis);
                pagesObject.addProperty("vs", periodToMillis);
            } else {
                WiseLog.d("current time : " + System.currentTimeMillis());
                WiseLog.d("last send time : " + lastSendTime);
                WiseLog.d("game vs -> " + ((System.currentTimeMillis() - lastSendTime) / 1000) + " seconds");
                pagesObject.addProperty("vs", System.currentTimeMillis() - lastSendTime);
            }
            pagesObject.addProperty("vtTz", System.currentTimeMillis());

            JsonObject dataObject = new JsonObject();
            dataObject.add("SESSION", sessionObject);
            dataObject.add("PAGES", pagesObject);

            DotManager.getInstance().sendGamePage(dataObject);
            lastSendTime = System.currentTimeMillis();

        } catch (Exception e) {
            WiseLog.e("send game page error", e);
        }

    }

}

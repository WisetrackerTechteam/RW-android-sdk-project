package com.sdk.wisetracker.new_dot.tracker.manager;

/**
 * 페이지 데이터 콜백 처리 interface
 */
public interface IPageCallBack {
    void onPageEvent();
}

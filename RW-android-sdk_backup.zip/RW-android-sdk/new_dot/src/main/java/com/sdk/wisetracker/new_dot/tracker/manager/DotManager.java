package com.sdk.wisetracker.new_dot.tracker.manager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import android.webkit.WebView;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.sdk.wisetracker.base.tracker.common.WisetrackerDatabase;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;
import com.sdk.wisetracker.base.tracker.data.manager.BasicDataManager;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.data.model.Session;
import com.sdk.wisetracker.new_dot.BuildConfig;
import com.sdk.wisetracker.new_dot.tracker.network.DotSendManager;
import com.sdk.wisetracker.new_dot.tracker.service.PlayService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;

/**
 * DOT 이벤트 발생시 처리 manager
 */
public class DotManager {

    private final String TAG = "DotManager";
    private List<Pair<String, Map<String, Object>>> tempList = new ArrayList<>();
    private List<JsonObject> dataList = new ArrayList<>();
    private static DotManager instance = null;

    public static DotManager getInstance() {
        if (instance == null) {
            instance = new DotManager();
        }
        return instance;
    }

    /**
     * SDK 초기화 수행
     * ActivityDetector.onActivityStarted(activity) 통해 호출
     * @param activity
     */
    public void init(Activity activity) {
        InitializeManager.init(activity.getApplicationContext());
        setSdkVersion();
        if( !InitializeManager.waitingForFbDeferred ){
            sdkInit();
        }
    }
    public void init(Context context) {
        InitializeManager.init(context);
        setSdkVersion();
        if( !InitializeManager.waitingForFbDeferred ){
            sdkInit();
        }
    }
    private void setSdkVersion() {
        // set sdk version
        SessionDataManager.getInstance().setSdkVersion(new Pair<>("DOT", BuildConfig.VERSION_NAME));
    }

    public void setOpenPlatform(String openPlatform) {
        SessionDataManager.getInstance().setOpenPlatform(openPlatform);
    }

    /**
     * SDK 초기화 상태에 따른 처리
     * Base 모듈의 초기화 이후 이벤트 동작
     */
    @SuppressLint("CheckResult")
    public void sdkInit() {
        try {
            if (InitializeManager.initComplete) {
                // base init complete before DotManager.init()
                sessionEvent();
                return;
            }
            InitializeManager.initSubject
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<Boolean>() {
                        @Override
                        public void accept(Boolean isInitComplete) {
                            // base init complete after DotManager.init()
                            sessionEvent();
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) {
                            WiseLog.e(throwable);
                        }
                    });
            SessionDataManager.deepLinkSubject
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<Boolean>() {
                        @Override
                        public void accept(Boolean complete) {
                            // 최초 실행인 경우에는 딥링크로 실행되어도, 인스톨 데이터와 함께 전송되어야 하므로 아래의 코드를 처리하지 않음.
                            // 2021.2.19 : 과거에는 its , wts 가 다르게 어트리뷰션 되는게 기준이었으나, 리플리케이스 마케팅사의 의견을 참고하여 its != wts 조건일때 wts => its로 처리하는 기준으로 변경됨에 따라서,
                            //             아래에 구현되었던 if 로직은 제거하였음.
                            //if(!BasicDataManager.getInstance().getBasicData().getIsFirstAppOpen().equals("Y")){
                                sessionEventByLink(); // isDrUpdate = Y 데이터 전송  이후에, 다시 N으로 돌려놓는 코드 추가.
                                Session _session = SessionDataManager.getInstance().getSession();
                                _session.setIsDeepLinkUpdate(null);
                           //}
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) {
                            WiseLog.e(throwable);
                        }
                    });
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    // 뉴세션시 세션 이벤트 발생
    public void sessionEvent() {
        WiseLog.d("session event");
        if (BasicDataManager.getInstance().isNewSession()) {
            dataList.add(0, MapDataManager.getSessionJsonObject());
        }
        checkTempList();
        DotSendManager.sendResult(dataList);
    }

    // 딥링크 오픈시 세션 데이터 전송
    private void sessionEventByLink() {
        WiseLog.d("session event by link");
        dataList.add(0, MapDataManager.getSessionJsonObject());
        if (InitializeManager.initComplete) {
            WiseLog.d("session event by link ( whatever install referrer ==> " + MapDataManager.getSessionJsonObject().toString());
            DotSendManager.sendResult(dataList);
        }
    }

    public void logEvent(Map<String, Object> map) {
        WiseLog.d("log event");
        if (InitializeManager.initComplete) {
            dataList.add(MapDataManager.getGoalJsonObject(map));
            DotSendManager.sendResult(dataList);
        } else {
            addTempList("event", map);
        }
    }

    public void logClick(Map<String, Object> map) {
        WiseLog.d("log click");
        if (InitializeManager.initComplete) {
            dataList.add(MapDataManager.getEventJsonObject(map));
            DotSendManager.sendResult(dataList);
        } else {
            addTempList("click", map);
        }
    }

    public void logPurchase(Map<String, Object> map) {
        WiseLog.d("log purchase");
        if (InitializeManager.initComplete) {
            dataList.add(MapDataManager.getRevenueJsonObject(map));
            DotSendManager.sendResult(dataList);
        } else {
            addTempList("purchase", map);
        }
    }

    public void logScreen(Map<String, Object> map) {
        WiseLog.d("log screen");
        MapDataManager.setPagesMap(map);
    }

    public void onStartPage(Context context) {
        MapDataManager.onStartPage(iPageCallBack);
        SequenceManager.getInstance().setSequence(context);
    }

    public void onStopPage() {
        MapDataManager.onStopPage(iPageCallBack);
    }

    // 페이지 이벤트 콜백 처리
    private IPageCallBack iPageCallBack = new IPageCallBack() {
        @Override
        public void onPageEvent() {
            if (InitializeManager.initComplete) {
                dataList.add(MapDataManager.getPagesJsonObject());
                DotSendManager.sendResult(dataList);
                MapDataManager.clearPageMapData(); // clear page data
            } else {
                addTempList("page", null);
            }
        }
    };

    public void onPlayStart(int period) {
        try {
            Context context = InitializeManager.applicationContext;
            if (context == null) {
                WiseLog.d("on play start -> context is null");
                return;
            }
            Intent intent = new Intent(context, PlayService.class);
            intent.setAction(PlayService.GAME_ACTION);
            intent.putExtra(PlayService.class.getSimpleName(), period);
            context.startService(intent);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    public void onPlayStop() {
        try {
            Context context = InitializeManager.applicationContext;
            if (context == null) {
                WiseLog.d("on play stop -> context is null");
                return;
            }
            Intent intent = new Intent(context, PlayService.class);
            context.stopService(intent);
        } catch (Exception e) {
            WiseLog.e("on stop game error", e);
        }
    }

    // 플레이 시간 설정에 맞춰 이벤트 자동 전송
    public void sendGamePage(JsonObject json) {
        dataList.add(json);
        DotSendManager.sendResult(dataList);
    }

    // 이벤트 발생시 미전송 데이터 확인 후 처리
    private void checkTempList() {
        if (tempList == null || tempList.isEmpty()) {
            return;
        }
        WiseLog.d("temp list size : " + tempList.size());
        for (Pair<String, Map<String, Object>> pair : tempList) {
            if (pair.first.equals("event")) {
                dataList.add(MapDataManager.getGoalJsonObject(pair.second));
            } else if (pair.first.equals("click")) {
                dataList.add(MapDataManager.getEventJsonObject(pair.second));
            } else if (pair.first.equals("purchase")) {
                dataList.add(MapDataManager.getRevenueJsonObject(pair.second));
            } else if (pair.first.equals("page")) {
                dataList.add(MapDataManager.getPagesJsonObject());
            }
        }
        tempList.clear();
    }

    // 초기화 수행 전 이벤트 발생시 데이터 저장
    private void addTempList(String type, Map<String, Object> map) {
        Pair<String, Map<String, Object>> pair = new Pair<>(type, map);
        tempList.add(pair);
    }

    public void setWebView(WebView webView) {
        DotWebViewManager.getInstance().setWebView(webView);
    }

    public void injectJavascript(WebView webView) {
        DotWebViewManager.getInstance().injectJavascript(webView);
    }

    public Map getAttributedInfo() throws Exception {
        String attributedJsonStr = WisetrackerDatabase.getStringValue("attributedInfo");
        Map<String, Object> retMap = new Gson().fromJson(
                attributedJsonStr, new TypeToken<HashMap<String, Object>>() {}.getType()
        );
        return retMap;
    }
}

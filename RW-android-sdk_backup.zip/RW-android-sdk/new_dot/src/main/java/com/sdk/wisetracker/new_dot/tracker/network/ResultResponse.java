package com.sdk.wisetracker.new_dot.tracker.network;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

/**
 * API 응답 모델 class
 */
public class ResultResponse {

    private @SerializedName("code") String code = null;
    private @SerializedName("msg") String message = null;
    private @SerializedName("result") boolean result = false;
    private @SerializedName("time") long connectionTime = 0;
    private @SerializedName("attributedInfo") Map attributedInfo = null;

    public boolean isResult() {
        return result;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public long getConnectionTime() {
        return connectionTime;
    }

    public Map getAttributedInfo() { return attributedInfo; }
}


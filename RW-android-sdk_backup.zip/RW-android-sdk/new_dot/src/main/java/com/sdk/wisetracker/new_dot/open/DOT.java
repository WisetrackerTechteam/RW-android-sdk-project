package com.sdk.wisetracker.new_dot.open;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebView;

import com.android.installreferrer.api.ReferrerDetails;
import com.sdk.wisetracker.base.open.model.InternalCampaign;
import com.sdk.wisetracker.base.open.model.User;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitAppOpen;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;
import com.sdk.wisetracker.base.tracker.data.manager.BasicData;
import com.sdk.wisetracker.base.tracker.data.manager.BasicDataManager;
import com.sdk.wisetracker.base.tracker.data.manager.FacebookReferrerDataManager;
import com.sdk.wisetracker.new_dot.tracker.controller.DotController;
import com.sdk.wisetracker.new_dot.tracker.init.ActivityDetector;
import com.sdk.wisetracker.new_dot.tracker.manager.DotManager;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * API
 */
public class DOT {
    private static Map resultMap;
    //String adId = null;
    //public Map<String,Object> resultMap = new HashMap<>();


    public static void initialization(Context context) {
        DotController.init(context);
        BasicDataManager.getInstance().getBasicData().setIsFirstOpenInSession(false);
    }

    public static void initialization(Activity activity) {
        DotController.init(activity);
        BasicDataManager.getInstance().getBasicData().setIsFirstOpenInSession(false);
    }

    /**
     * 초기화 API
     * SDK 내부적으로 호출하여 초기화 진행
     * @param activity
     */
//    public static void init(Activity activity) {
//        DotController.init(activity);
//        BasicDataManager.getInstance().getBasicData().setIsFirstOpenInSession(false);
//    }
//    public static void init(Context context){
//        DotController.init(context);
//        BasicDataManager.getInstance().getBasicData().setIsFirstOpenInSession(false);
//    }


    /**
     * 플랫폼 확인 API
     * 플러그인 내부적으로 호출하여 플랫폼 확인 (플러그인 코드에 적용 완료)
     * @param openPlatform
     */
    public static void open(String openPlatform) {
        DotController.open(openPlatform);
    }

    /**
     * 푸시 수신 API
     * 앱에서 푸시 수신시 호출
     * @param intent
     */
    public static void setPushReceiver(Intent intent) {
        DotController.setPushReceiver(intent);
    }
    /**
     * 푸시 클릭 API
     * 앱에서 푸시 클릭시 호출
     * @param intent
     */
    public static void setPushClick(Context context, Intent intent) {
        if( !InitializeManager.initComplete ){
            DOT.initialization(context);
            ActivityDetector.getInstance().setIsFirst(false);
        }
        DotController.setPushClick(intent);
    }

    /**
     * 푸시 클릭 API
     * 앱에서 발급된 푸시 토큰 등록시 호출
     * @param pushToken
     */
    public static void setPushToken(String pushToken) {
        DotController.setPushToken(pushToken);
    }

    /**
     * 푸시 클릭 API
     * 딥링크 수신시 호출
     * @param intent
     */
    public static void setDeepLink(Context context, Intent intent) {
        if( !InitializeManager.initComplete ){
            DOT.initialization(context);
            ActivityDetector.getInstance().setIsFirst(false);
        }
        DotController.setDeepLink(intent);
    }

    /**
     * 푸시 클릭 API
     * 딥링크 수신시 호출
     * @param url (deepLinkUrl)
     */
    public static void setDeepLink(Context context, String url) {
        if( !InitializeManager.initComplete ){
            DOT.initialization(context);
            ActivityDetector.getInstance().setIsFirst(false);
        }
        DotController.setDeepLink(url);
    }


    /**
     * 인스톨 레퍼러 수신 API
     * 인스톨 레퍼러 자체 분석시 호출
     * @param referrerDetails
     */
    public static void setInstallReferrer(ReferrerDetails referrerDetails) {
        DotController.setInstallReferrer(referrerDetails);
    }

    /**
     * 페이스북 디퍼드 딥링크 수신 API
     * 페이스북 디퍼드 딥링크 사용시 호출
     * @param bundle
     */
    public static void receiveFailFacebookReferrer(int type){
        switch(type){
            case 1 : WiseLog.d("Facebook AppLinkData is null"); break;
            case 2 : WiseLog.d("Facebook Bundle data is null");break;
        }
        FacebookReferrerDataManager.getInstance().setReferrerData("",0);
        if( InitializeManager.waitingForFbDeferred ){
            InitializeManager.waitingForFbDeferred = false;
            DotManager.getInstance().sdkInit();
        }
    }

    public static void setFacebookReferrer(Bundle bundle) {
        DotController.setFacebookReferrer(bundle);
        if( InitializeManager.waitingForFbDeferred ){
            InitializeManager.waitingForFbDeferred = false;
            DotManager.getInstance().sdkInit();
        }
    }

    /**
     * 유저 정보 API
     * 유저 로그인시 호출
     * @param user
     */
    public static void setUser(User user) {
        DotController.setUser(user);
    }

    /**
     * 유저 로그아웃 API
     * 유저 로그아웃시 호출
     */
    public static void setUserLogout() {
        DotController.setUserLogout();
    }

    /**
     * Internal Campaign
     */
    public static void setInternalCampaign(InternalCampaign campaign){
        DotController.setInternalCampaign(campaign);
    }

    /**
     * 체류시간 측정 API
     * 기본 체류시간 측정 파라메터 없을 시 기본 값 15분 설정
     */
    public static void onPlayStart() {
        DotController.onPlayStart(0);
    }

    /**
     * 체류시간 측정 API
     * 전달 받은 파라메터에 따른 분 단위 체류 시간 데이터 전송
     * @param period
     */
    public static void onPlayStart(int period) {
        DotController.onPlayStart(period);
    }

    /**
     * 체류 시간 측정 종료 API
     * 앱 이탈시 호출
     */
    public static void onPlayStop() {
        DotController.onPlayStop();
    }

    /**
     * 페이지 시간 측정 API
     * 페이지 이탈시 호출
     * @param context
     */
    public static void onStartPage(Context context) {
        DotController.onStartPage(context);
    }

    /**
     * 페이지 시간 측정 종료 API
     * 페이지 이탈시 호출
     */
    public static void onStopPage() {
        DotController.onStopPage();
    }

    /**
     * Page 이벤트 발생시 호출 API
     * @param map
     */
    public static void logScreen(Map<String, Object> map) {
        DotController.logScreen(map);
    }

    /**
     * Conversion 이벤트 발생시 호출 API
     * @param map
     */
    public static void logEvent(Map<String, Object> map) {
        DotController.logEvent(map);
    }

    /**
     * Click 이벤트 발생시 호출 API
     * @param map
     */
    public static void logClick(Map<String, Object> map) {
        DotController.logClick(map);
    }

    /**
     * Revenue 이벤트 발생시 호출 API
     * @param map
     */
    public static void logPurchase(Map<String, Object> map) {
        DotController.logPurchase(map);
    }

    /**
     * 웹뷰 설정 API
     * 웹뷰 로드시 호출
     * @param webView
     */
    public static void setWebView(WebView webView) {
        DotController.setWebView(webView);
    }

    /**
     * 웹뷰 이용시 .js 파일 인젝트를 위해 호출 API
     * @param webView
     */

    public static Map<String,Object> getWebviewClientStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("startPage", false);
        status.put("pageRedirect", 0);
        return status;
    }
    public static void updatePageStartStatus(Map<String,Object> status ){
        try{
            boolean startPage = (Boolean)status.get("startPage");
            int pageRedirect = (int)status.get("pageRedirect");
            if(!startPage && pageRedirect == 0 ){
                status.put("startPage", true);
                status.put("pageRedirect", 1 );
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void updateShouldOverrideUrlLoadingStatus(Map<String,Object> status){
        try{
            boolean startPage = (Boolean)status.get("startPage");
            int pageRedirect = (int)status.get("pageRedirect");
            if(startPage){
                pageRedirect++;
                status.put("pageRedirect", pageRedirect);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static boolean checkOnPageFinished(Map<String,Object> status){
        boolean flag = false;
        try{
            boolean startPage = (Boolean)status.get("startPage");
            int pageRedirect = (int)status.get("pageRedirect");
            if( startPage ){
                pageRedirect--;
                if( pageRedirect <= 0){
                    flag = true;
                    status.put("startPage", false);
                    status.put("pageRedirect", 0 );
                }else{
                    status.put("pageRedirect", pageRedirect);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return flag;
    }
    public static void injectJavascript(WebView webView) {
        if (webView == null || webView.getContext() == null) {
            WiseLog.d("web view or context is null");
            return;
        }
        DOT.onStartPage(webView.getContext());
        DotController.injectJavascript(webView);
    }

    /**
     * Attributed info
     */
//    public static Map getAttributedInfo() {
//        Map<String, Object> result = new HashMap<>();
//        for (int i = 0; i <= 5; i++) {
//            try {
//                result = DotController.getAttributedInfo();
//                WiseLog.d("index result in getAttributedInfo: " + result);
//                if (result != null && result.size() > 0) {
//                    break;
//                }
//                Thread.sleep(1000);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        if (result == null) {
//            result = new HashMap<>();
//        }
//        return result;
//    }



    public interface AttributedInfoCallback {
        void doTask(Map<String,Object> result);
    }

    public static void getAttributedInfo(DOT.AttributedInfoCallback callback) {
         Observable.fromCallable(() -> {
                Map<String, Object> temp = new HashMap<>();
                for (int i = 0; i <= 10; i++) {
                    try {
                        //setAttributedByDelay();
                        temp = DotController.getAttributedInfo();
                        if (temp != null && temp.size() > 0) {
                            break;
                        }
                        Thread.currentThread().sleep(1000);
                        //Thread.sleep(1000);
                        WiseLog.d("mrcm2 Thread id "+ Thread.currentThread().getId());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (temp == null) {
                    temp = new HashMap<>();
                }
            return temp;
        })
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe((result) -> {
            System.out.println("mrcm2" + result);
            System.out.println("mrcm2 callback pass data " + result);
            callback.doTask(result);
            System.out.println("mrcm2 callback caller end.");

        });
    }

    public static void setAttributedByDelay() {
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                // this code will be executed after 2 seconds
                try {
                    resultMap = DotController.getAttributedInfo();
                    WiseLog.d("before attributed info: " + resultMap);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);
    }



}

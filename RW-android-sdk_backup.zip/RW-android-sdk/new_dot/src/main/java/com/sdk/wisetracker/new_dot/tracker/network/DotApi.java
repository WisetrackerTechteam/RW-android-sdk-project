package com.sdk.wisetracker.new_dot.tracker.network;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * DOT 이벤트 데이터 전송 API
 */
public interface DotApi {

    @POST("dot/v1/dataRcv.do")
    Observable<ResultResponse> sendTransaction(@Body RequestBody requestBody);

}

package com.sdk.wisetracker.new_dot.tracker.network;

import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.network.BaseRetrofit;
import com.sdk.wisetracker.base.tracker.network.interceptor.RetrofitHeaderInterceptor;
import com.sdk.wisetracker.base.tracker.network.interceptor.RetrofitLogInterceptor;
import com.sdk.wisetracker.base.tracker.network.type.HeaderType;

import okhttp3.Interceptor;

/**
 * 네트워크 설정 util class
 */
public class DotRetrofit extends BaseRetrofit<DotApi> {

    private static DotRetrofit instance = null;

    public static DotRetrofit getInstance() {
        if (instance == null) {
            instance = new DotRetrofit();
        }
        return instance;
    }

    @Override
    public String getTag() {
        return "DotRetrofit";
    }

    // 전송 URL
    @Override
    public String getUrl() {
        return SessionDataManager.getInstance().getSession().getDomain();
    }

    @Override
    public Interceptor getHeaderInterceptor(HeaderType type) {
        return new RetrofitHeaderInterceptor(getTag(), type);
    }

    @Override
    public Interceptor getLogInterceptor() {
        return new RetrofitLogInterceptor(getTag());
    }

}

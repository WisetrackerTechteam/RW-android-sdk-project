package com.sdk.wisetracker.new_dot.tracker.init;

import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import com.sdk.wisetracker.base.BuildConfig;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

import java.util.Objects;

import io.reactivex.annotations.NonNull;
import io.reactivex.annotations.Nullable;

/**
 * 앱 실행시 SDK 자동 초기화 설정 class
 */
public class TrackerProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        try {
            WiseLog.d("App provider create");
            WiseLog.d("APP MODE -> isDebug = " + BuildConfig.DEBUG);
            Context context = Objects.requireNonNull(getContext()).getApplicationContext();
            if (context instanceof Application) {
                ActivityDetector.getInstance().setApplication((Application) context);
            }
        } catch (Exception e) {
            Log.e("Provider", "on create error !!", e);
        }
        return true;
    }


    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }


    @Override
    public String getType(Uri uri) {
        return null;
    }


    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

}

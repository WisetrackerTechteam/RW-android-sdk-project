package com.sdk.wisetracker.new_dot.open;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.android.installreferrer.api.ReferrerDetails;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.sdk.wisetracker.base.open.model.User;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.model.Const;

import java.lang.reflect.Type;
import java.util.Map;

/**
 * Unity gradle 빌드시 플러그인 역할 class
 */
public class DOTHelper {

    private static DOTHelper instance = null;

    public static DOTHelper getInstance() {
        if (instance == null) {
            instance = new DOTHelper();
        }
        return instance;
    }

    // common
    public void initialization() {
        DOT.open("Unity");
        WiseLog.d("initialization !!");
    }

    public void setPushReceiver(String campaignId, String pushID) {
        JsonObject object = new JsonObject();
        object.addProperty(Const.PUSH_CAMPAIGN_ID, campaignId);
        object.addProperty(Const.PUSH_ID, pushID);

        Intent intent = new Intent();
        intent.putExtra(Const.PUSH_EXTRA_DATA, object.toString());

        DOT.setPushReceiver(intent);
    }

    public void setPushClick(Context context, String pushId, String campaignId, String pushTitle, String pushBody, long expireTime) {

        JsonObject object = new JsonObject();
        object.addProperty(Const.PUSH_ID, pushId);
        object.addProperty(Const.PUSH_CAMPAIGN_ID, campaignId);
        object.addProperty(Const.PUSH_TITLE, pushTitle);
        object.addProperty(Const.PUSH_BODY, pushBody);
        object.addProperty(Const.PUSH_EXPIRE_TIME, expireTime);

        Intent intent = new Intent();
        intent.putExtra(Const.PUSH_EXTRA_DATA, object.toString());

        DOT.setPushClick(context, intent);
    }


    public void setPushToken(String pushToken) {
        DOT.setPushToken(pushToken);
    }

    public void setDeepLink(Context context, String url) {
        DOT.setDeepLink(context, url);
    }

    public void setInstallReferrer(ReferrerDetails referrerDetails) {
        DOT.setInstallReferrer(referrerDetails);
    }

    public void setFacebookReferrer(String targetUrl) {
        Bundle bundle = new Bundle();
        bundle.putString("target_url", targetUrl);
        DOT.setFacebookReferrer(bundle);
    }

    // dot
    public void setUser(String userString) {
        if (TextUtils.isEmpty(userString)) {
            return;
        }
        User userData = new Gson().fromJson(userString, User.class);
        if (userData == null) {
            WiseLog.d("convert user data is null !!");
            return;
        }
        WiseLog.d("user object data : " + new Gson().toJson(userData));
        DOT.setUser(userData);
    }

    public void setUserLogout() {
        DOT.setUserLogout();
    }

    public void onPlayStart() {
        DOT.onPlayStart(0);
    }

    public void onPlayStart(int period) {
        DOT.onPlayStart(period);
    }

    public void onPlayStop() {
        DOT.onPlayStop();
    }

    public void onStartPage() {
        DOT.onStartPage(null);
    }

    public void onStopPage() {
        DOT.onStopPage();
    }

    public void logScreen(String pageJson) {
        try {
            WiseLog.d("log screen event");
            if (TextUtils.isEmpty(pageJson)) {
                WiseLog.d("page json is null");
                return;
            }
            WiseLog.d("raw data : " + pageJson);
            Type type = new TypeToken<Map<String, Object>>() {
            }.getType();
            Map<String, Object> pageMap = new Gson().fromJson(pageJson, type);
            if (pageMap == null) {
                WiseLog.d("page map is null");
                return;
            }
            DOT.logScreen(pageMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    public void logPurchase(String purchaseJson) {
        try {
            WiseLog.d("log purchase event");
            if (TextUtils.isEmpty(purchaseJson)) {
                WiseLog.d("purchase json is null");
                return;
            }
            WiseLog.d("raw data : " + purchaseJson);
            Type type = new TypeToken<Map<String, Object>>() {
            }.getType();
            Map<String, Object> purchaseMap = new Gson().fromJson(purchaseJson, type);
            if (purchaseMap == null) {
                WiseLog.d("purchase map is null");
                return;
            }
            DOT.logPurchase(purchaseMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    public void logEvent(String conversionJson) {
        try {
            WiseLog.d("log conversion event");
            if (TextUtils.isEmpty(conversionJson)) {
                WiseLog.d("conversion json is null");
                return;
            }
            WiseLog.d("raw data : " + conversionJson);
            Type type = new TypeToken<Map<String, Object>>() {
            }.getType();
            Map<String, Object> conversionMap = new Gson().fromJson(conversionJson, type);
            if (conversionMap == null) {
                WiseLog.d("conversion map is null");
                return;
            }
            DOT.logEvent(conversionMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    public void logClick(String clickJson) {
        try {
            WiseLog.d("log click event");
            if (TextUtils.isEmpty(clickJson)) {
                WiseLog.d("click json is null");
                return;
            }
            WiseLog.d("raw data : " + clickJson);
            Type type = new TypeToken<Map<String, Object>>() {
            }.getType();
            Map<String, Object> clickMap = new Gson().fromJson(clickJson, type);
            if (clickMap == null) {
                WiseLog.d("click map is null");
                return;
            }
            DOT.logClick(clickMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

}

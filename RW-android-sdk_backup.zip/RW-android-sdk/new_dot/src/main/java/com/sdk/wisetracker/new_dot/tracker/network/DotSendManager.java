package com.sdk.wisetracker.new_dot.tracker.network;

import android.annotation.SuppressLint;
import android.text.TextUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sdk.wisetracker.base.tracker.common.WisetrackerDatabase;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.common.log.WiseValidation;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;
import com.sdk.wisetracker.base.tracker.data.manager.BasicData;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.network.type.HeaderType;
import com.sdk.wisetracker.new_dot.tracker.manager.MapDataManager;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * DOT 이벤트 데이터 전송 class
 */
public class DotSendManager {

    @SuppressLint("CheckResult")
    public static void sendResult(final List<JsonObject> resultList) {

        if (!InitializeManager.initComplete) {
            return;
        }

        if (resultList == null || resultList.isEmpty()) {
            return;
        }

        WiseLog.d("DOT_RESULT_SIZE -> " + resultList.size());

        String jsonString = getJsonString(resultList);
        if (TextUtils.isEmpty(jsonString)) {
            return;
        }

        Observable.just(jsonString)
                .flatMap(new Function<String, ObservableSource<ResultResponse>>() {
                    @Override
                    public ObservableSource<ResultResponse> apply(String result) {
                        MediaType mediaType = MediaType.parse("application/octet-stream");
                        byte[] binary = getResultToBinary(result);
                        RequestBody requestBody = RequestBody.create(mediaType, binary);
                        DotApi api = DotRetrofit.getInstance().getBaseApi(DotApi.class, HeaderType.DOT);
                        return api.sendTransaction(requestBody);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<ResultResponse>() {
                    @Override
                    public void accept(ResultResponse resultResponse) {
                        // 전송 완료 후 전송 데이터 validation 호출
                        WiseValidation.dotSdkValidation(jsonString);
                        try {
                            setAttributedInfo(resultResponse.getAttributedInfo());
                        } catch (Exception e) {
                            WiseLog.e(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) {
                        WiseLog.e(throwable);
                    }
                }, new Action() {
                    @Override
                    public void run() {
                        // 초기화
                        SessionDataManager.getInstance().updateSessionAfterTransaction();
                        WiseLog.d("DOT_SEND_COMPLETE");
                    }
                });

    }

    private static void setAttributedInfo(Map<String, Object> attributedInfo) throws UnsupportedEncodingException {
        Map<String, Object> installMap = new HashMap<>();
        Map<String, Object> installInfo = new HashMap<>();
        Map<String, Object> openMap = new HashMap<>();
        Map<String, Object> openInfo = new HashMap<>();

        String installCampaignNm = "";
        String installMediaNm = "";
        String installAdid = "";
        String openCampaignNm = "";
        String openMediaNm = "";
        String openAdid= "";

        Map<String, Object> receivedInstallInfo = new HashMap<>();
        Map<String, Object> receivedOpenInfo = new HashMap<>();
        Map<String, Object> receivedAttributedInfo = new HashMap<>();

        if(attributedInfo.containsKey("install")) {
            installMap = (Map)attributedInfo.get("install");
            if(installMap.containsKey("bean")) {
                installInfo = (Map)installMap.get("bean");
                WiseLog.d("installInfo in setAttributedInfo: " + installInfo);
                if (installInfo.containsKey("wtcNm") ){
                    installCampaignNm = (String) installInfo.get("wtcNm");
                    installCampaignNm = URLDecoder.decode(installCampaignNm, "UTF-8");
                }
                if (installInfo.containsKey("wtsNm") ){
                    installMediaNm = (String) installInfo.get("wtsNm");
                    installMediaNm = URLDecoder.decode(installMediaNm, "UTF-8");
                }
                if (installInfo.containsKey("adid") ){
                    installAdid = (String) installInfo.get("adid");
                    installAdid = URLDecoder.decode(installAdid, "UTF-8");
                }
            } else {
                installCampaignNm = "organic";
                installMediaNm = "organic";
                installAdid = "";
            }
        }
        if(attributedInfo.containsKey("open")) {
            openMap = (Map) attributedInfo.get("open");
            if (openMap.containsKey("bean")) {
                openInfo = (Map) openMap.get("bean");
                if (openInfo.containsKey("wtcNm") ){
                    openCampaignNm = (String) openInfo.get("wtcNm");
                    openCampaignNm = URLDecoder.decode(openCampaignNm, "UTF-8");
                }
                if (openInfo.containsKey("wtsNm") ){
                    openMediaNm = (String) openInfo.get("wtsNm");
                    openMediaNm = URLDecoder.decode(openMediaNm, "UTF-8");
                }
                if (openInfo.containsKey("adid") ) {
                    openAdid = (String) openInfo.get("adid");
                    openAdid = URLDecoder.decode(openAdid, "UTF-8");
                }
            } else {
                openCampaignNm = "organic";
                openMediaNm = "organic";
                openAdid = "";
            }
        }

        if(installCampaignNm.length() != 0) {
            receivedAttributedInfo.put("installCampaign", installCampaignNm);
        }
        if(installMediaNm.length() != 0) {
            receivedAttributedInfo.put("installMedia", installMediaNm);
        }

        receivedAttributedInfo.put("installAdid", installAdid);


        if(openCampaignNm.length() != 0) {
            receivedAttributedInfo.put("openCampaign", openCampaignNm);
        }
        if(openMediaNm.length() != 0) {
            receivedAttributedInfo.put("openMedia", openMediaNm);
        }

        receivedAttributedInfo.put("openAdid", openAdid);

        WisetrackerDatabase.setDatabase("attributedInfo", receivedAttributedInfo);
    }
    // 데이터 전송 리스트 json 형태로 변환
    private static String getJsonString(List<JsonObject> resultList) {
        try {
            List<JsonObject> dataList = new ArrayList<>();
            dataList.addAll(resultList);
            resultList.clear();
            JsonArray jsonArray = new JsonArray();
            for (JsonObject json : dataList) {
                /*
                * session 데이터 전송시에  receivedInAppMessageData 키값은 클라이언트가 수신받은 전체 in-app 메시지 데이터 이므로, 서버로 전송이 불 필요할 수 있음.
                * 때문에 session 에서 전송시에 해당 키값은 삭제후 전송하도록 처리. ( 저장된 session 데이터와는 무관, 전송 시점에만 삭제후 전송 )
                **/
                if( json.has("SESSION")){
                    JsonObject session = json.get("SESSION").getAsJsonObject();
                    if( session != null && session.has("receivedInAppMessageData")){
                        session.remove("receivedInAppMessageData");
                    }
                }
                jsonArray.add(json);
            }
            return jsonArray.toString();
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

    // json -> byte[] 데이터 변환
    private static byte[] getResultToBinary(String resultJsonString) {
        try {
            WiseLog.d("DOT_JSON_STRING -> " + resultJsonString);
            byte[] binary = compressJsonString(resultJsonString);
            return binary;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

    // 데이터 압축 후 byte[] 형태로 리턴
    private static byte[] compressJsonString(String json) {

        try {

            String encodeString = URLEncoder.encode(json, "utf-8");
            byte[] encodeByte = encodeString.getBytes();

            Deflater deflater = new Deflater();
            deflater.setLevel(Deflater.BEST_COMPRESSION);
            deflater.setInput(encodeByte);
            deflater.finish();

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream(encodeByte.length);
            byte[] buffer = new byte[1024];

            while (!deflater.finished()) {
                int compByte = deflater.deflate(buffer);
                outputStream.write(buffer, 0, compByte);
            }
            outputStream.close();
            deflater.end();

            byte[] returnByte = outputStream.toByteArray();
            return returnByte;

        } catch (Exception e) {
            WiseLog.e(e);
        }

        return null;

    }

}

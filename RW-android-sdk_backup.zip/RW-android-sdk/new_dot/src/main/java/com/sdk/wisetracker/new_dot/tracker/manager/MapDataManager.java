package com.sdk.wisetracker.new_dot.tracker.manager;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.base.tracker.data.model.Session;

import java.util.Iterator;
import java.util.Map;

/**
 * 이벤트 발생시  json 데이터 생성 class
 */
public class MapDataManager {

    // parameter validation check
    private static JsonObject getJsonObject(Map<String, Object> map) {
        try {
            if (map == null) {
                return null;
            }
            JsonElement jsonElement = new JsonParser().parse(new Gson().toJson(map));
            if (jsonElement == null) {
                return null;
            }
            if (!jsonElement.isJsonObject()) {
                return null;
            }
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            // 생성시간 프로퍼티 추가
            jsonObject.addProperty("vtTz", System.currentTimeMillis());
            return jsonObject;
        } catch (Exception e) {
            WiseLog.e(e);
        }
        return null;
    }

    private static JsonObject getSession() {
        Session session = SessionDataManager.getInstance().getUpdateSessionData();
        JsonElement sessionElement = new JsonParser().parse(new Gson().toJson(session));
        JsonObject sessionObject = sessionElement.getAsJsonObject();
        //sessionObject.addProperty("pageKey", SequenceManager.getInstance().getSequence());
        return sessionObject;
    }

    public static JsonObject getSessionJsonObject() {
        JsonObject sessionObject = new JsonObject();
        sessionObject.add("SESSION", getSession());
        return sessionObject;
    }

    // goal
    public static JsonObject getGoalJsonObject(Map<String, Object> map) {
        JsonObject jsonObject = getJsonObject(map);
        if (jsonObject == null) {
            return null;
        }
        JsonObject goalObject = new JsonObject();
        goalObject.add("SESSION", getSession());
        goalObject.add("GOAL", jsonObject);
        return goalObject;
    }

    // click
    public static JsonObject getEventJsonObject(Map<String, Object> map) {
        JsonObject jsonObject = getJsonObject(map);
        if (jsonObject == null) {
            return null;
        }
        JsonObject clickObject = new JsonObject();
        clickObject.add("SESSION", getSession());
        clickObject.add("CLICK", jsonObject);
        return clickObject;
    }

    // revenue
    public static JsonObject getRevenueJsonObject(Map<String, Object> map) {
        JsonObject jsonObject = getJsonObject(map);
        if (jsonObject == null) {
            return null;
        }
        addPurchaseDataToSession(map);
        JsonObject revenueObject = new JsonObject();
        revenueObject.add("SESSION", getSession());
        revenueObject.add("REVENUE", jsonObject);
        return revenueObject;
    }

    // revenue data to session
    private static void addPurchaseDataToSession(Map<String, Object> map) {

        try {

            if (!map.containsKey("product")) {
                return;
            }

            JsonElement jsonElement = new JsonParser().parse(new Gson().toJson(map.get("product")));
            if (jsonElement == null) {
                return;
            }

            int productPrice = 0;
            if (jsonElement.isJsonObject()) {
                WiseLog.d("jsonElement in log addPurchaseDataToSession:" + jsonElement);
                String priceString = "";
                if(jsonElement.getAsJsonObject().has("amt")) {
                    priceString = jsonElement.getAsJsonObject().get("amt").getAsString();
                    WiseLog.d("amt in log addPurchaseDataToSession:" + priceString);
                    if (priceString.contains(",")) {
                        priceString = priceString.replace(",", "");
                    }
                } else if(jsonElement.getAsJsonObject().has("revenue")) {
                    priceString = jsonElement.getAsJsonObject().get("revenue").getAsString();
                    WiseLog.d("revenue in log addPurchaseDataToSession:" + priceString);
                    if (priceString.contains(",")) {
                        priceString = priceString.replace(",", "");
                    }
                }
                productPrice = Integer.valueOf(priceString);
            } else if (jsonElement.isJsonArray()) {
                Iterator iterator = jsonElement.getAsJsonArray().iterator();
                while (iterator.hasNext()) {
                    JsonElement objectElement = (JsonElement) iterator.next();
                    if (objectElement.isJsonObject()) {
                        if(objectElement.getAsJsonObject().has("amt")) {
                            String priceString = objectElement.getAsJsonObject().get("amt").getAsString();
                            if (priceString.contains(",")) {
                                priceString = priceString.replace(",", "");
                            }
                            productPrice += Integer.valueOf(priceString);
                        } else if(objectElement.getAsJsonObject().has("revenue")) {
                            String priceString = objectElement.getAsJsonObject().get("revenue").getAsString();
                            if (priceString.contains(",")) {
                                priceString = priceString.replace(",", "");
                            }
                            productPrice += Integer.valueOf(priceString);
                        }
                    }
                }
            }

            String orderNumber = null;
            if (map.containsKey("ordNo")) {
                orderNumber = String.valueOf(map.get("ordNo"));
            } else if (map.containsKey("transaction_id")) {
                orderNumber = String.valueOf(map.get("transaction_id"));
            }

            SessionDataManager.getInstance().onPurchaseEvent(productPrice, orderNumber);

        } catch (Exception e) {
            WiseLog.e(e);
        }

    }

    // page event
    private static Map<String, Object> pagesMap = null;
    private static long lastPageOpenTime = 0;
    private static int pageReference = 0;

    public static void onStartPage(IPageCallBack iPageCallBack) {
        try {
            pageReference++;
            WiseLog.d("onStartPage() reference : " + pageReference);
            if (pageReference > 1) {
                iPageCallBack.onPageEvent();
                pageReference--;
            }
            lastPageOpenTime = System.currentTimeMillis();
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    public static void onStopPage(IPageCallBack iPageCallBack) {
        try {
            WiseLog.d("onStopPage() reference : " + pageReference);
            if (pageReference > 0) {
                iPageCallBack.onPageEvent();
                pageReference--;
            }
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    public static void setPagesMap(Map<String, Object> map) {
        pagesMap = map;
    }
    public static void clearPageMapData(){
        pagesMap = null;
    }
    public static JsonObject getPagesJsonObject() {

        WiseLog.d("pagesMap in getPagesJsonObject : " + pagesMap);
        JsonObject jsonObject = getJsonObject(pagesMap);
        if (jsonObject == null) {
            jsonObject = new JsonObject();
            jsonObject.addProperty("vtTz", System.currentTimeMillis());
        }

        // 페이지 생성시간, 체류 시간 추가
        long vs =  (System.currentTimeMillis() - lastPageOpenTime) / 1000;
        jsonObject.addProperty("vs", vs);
        addPageDataToSession(pagesMap);

        JsonObject pagesObject = new JsonObject();
        pagesObject.add("SESSION", getSession());
        pagesObject.add("PAGES", jsonObject);
        return pagesObject;

    }

    // page data add to sesison
    private static void addPageDataToSession(Map<String, Object> map) {
        try {
            String searchResultCount = null;
            String pageIdentify = null;
            if (map != null) {
                if (map.containsKey("sresult")) {
                    searchResultCount = String.valueOf(map.get("sresult"));
                }
                if (map.containsKey("pi")) {
                    pageIdentify = String.valueOf(map.get("pi"));
                } else if (map.containsKey("page_id")) {
                    pageIdentify = String.valueOf(map.get("page_id"));
                }
            }
            SessionDataManager.getInstance().onPageEvent(searchResultCount, pageIdentify);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

}

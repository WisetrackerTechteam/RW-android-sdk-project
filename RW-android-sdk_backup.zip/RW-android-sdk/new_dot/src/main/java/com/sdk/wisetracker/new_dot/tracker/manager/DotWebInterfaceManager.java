package com.sdk.wisetracker.new_dot.tracker.manager;

import android.text.TextUtils;
import android.webkit.JavascriptInterface;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sdk.wisetracker.base.open.model.User;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.SessionDataManager;
import com.sdk.wisetracker.new_dot.open.DOT;

import java.lang.reflect.Type;
import java.util.Map;

/**
 * 웹뷰 <-> SDK 연동 브릿지 class
 */
public class DotWebInterfaceManager {

    private final String TAG = "WisetrackerWebInterfaceManager";

    @JavascriptInterface
    public void setUser(String json) {
        try {
            WiseLog.d("setUser event :" + json);
            Gson gson = new Gson();
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> tempMap = new Gson().fromJson(json, type);
            String tmpJson = gson.toJson(tempMap.get("_data"));
            User user = new Gson().fromJson(tmpJson, User.class);

            if (user == null) {
                return;
            }
            SessionDataManager.getInstance().setUser(user);
        } catch (Exception e) {
            WiseLog.d(e.getMessage());
        }
    }

    @JavascriptInterface
    public void setUserLogout() {
        try {
            SessionDataManager.getInstance().setUserLogout();
        } catch (Exception e) {
            WiseLog.d(e.getMessage());
        }
    }

    @JavascriptInterface
    public void onPlayStart() {
        DOT.onPlayStart(0);
    }

    @JavascriptInterface
    public void onPlayStart(int period) {
        DOT.onPlayStart(period);
    }

    @JavascriptInterface
    public void onPlayStop() {
        DOT.onPlayStop();
    }

    @JavascriptInterface
    public void onStartPage() {
        DOT.onStartPage(null);
    }

    @JavascriptInterface
    public void onStopPage() {
        DOT.onStopPage();
    }

    @JavascriptInterface
    public void logScreen(String pageJson) {
        try {
            WiseLog.d("log screen event");
            if (TextUtils.isEmpty(pageJson)) {
                WiseLog.d("page json is null");
                return;
            }
            WiseLog.d("raw data : " + pageJson);
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> pageMap = new Gson().fromJson(pageJson, type);
            if (pageMap == null) {
                WiseLog.d("page map is null");
                return;
            }
            DOT.logScreen(pageMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    @JavascriptInterface
    public void logPurchase(String purchaseJson) {
        try {
            WiseLog.d("log purchase event");
            if (TextUtils.isEmpty(purchaseJson)) {
                WiseLog.d("purchase json is null");
                return;
            }
            WiseLog.d("raw data : " + purchaseJson);
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> purchaseMap = new Gson().fromJson(purchaseJson, type);
            if (purchaseMap == null) {
                WiseLog.d("purchase map is null");
                return;
            }
            DOT.logPurchase(purchaseMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    @JavascriptInterface
    public void logEvent(String conversionJson) {
        try {
            WiseLog.d("log conversion event");
            if (TextUtils.isEmpty(conversionJson)) {
                WiseLog.d("conversion json is null");
                return;
            }
            WiseLog.d("raw data : " + conversionJson);
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> conversionMap = new Gson().fromJson(conversionJson, type);
            if (conversionMap == null) {
                WiseLog.d("conversion map is null");
                return;
            }
            DOT.logEvent(conversionMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

    @JavascriptInterface
    public void logClick(String clickJson) {
        try {
            WiseLog.d("log click event");
            if (TextUtils.isEmpty(clickJson)) {
                WiseLog.d("click json is null");
                return;
            }
            WiseLog.d("raw data : " + clickJson);
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> clickMap = new Gson().fromJson(clickJson, type);
            if (clickMap == null) {
                WiseLog.d("click map is null");
                return;
            }
            DOT.logClick(clickMap);
        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

}


  /*
    @Deprecated
    @JavascriptInterface
    public void setPage(String json) {
        try {
            Map<String, String> map = new HashMap<>();
            map.put("type", "page");
            map.put("data", json);
            WebViewManager.getInstance().setData(map);
        } catch (Exception e) {
            WiseLog.d(e.getMessage());
        }
    }

    @Deprecated
    @JavascriptInterface
    public void setClick(String json) {
        try {
            Map<String, String> map = new HashMap<>();
            map.put("type", "click");
            map.put("data", json);
            WebViewManager.getInstance().setData(map);
        } catch (Exception e) {
            WiseLog.d(e.getMessage());
        }
    }

    @Deprecated
    @JavascriptInterface
    public void setConversion(String json) {
        try {
            Map<String, String> map = new HashMap<>();
            map.put("type", "conversion");
            map.put("data", json);
            WebViewManager.getInstance().setData(map);
        } catch (Exception e) {
            WiseLog.d(e.getMessage());
        }
    }

    @Deprecated
    @JavascriptInterface
    public void setPurchase(String json) {
        try {
            Map<String, String> map = new HashMap<>();
            map.put("type", "purchase");
            map.put("data", json);
            WebViewManager.getInstance().setData(map);
        } catch (Exception e) {
            WiseLog.d(e.getMessage());
        }
    }
    */
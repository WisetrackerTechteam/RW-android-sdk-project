package com.sdk.wisetracker.new_dot.tracker.controller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.webkit.WebView;

import com.sdk.wisetracker.base.open.controller.BaseController;
import com.sdk.wisetracker.new_dot.tracker.manager.DotManager;

import java.util.Map;

/**
 * DOT 이벤트 관련 처리 controller
 */
public class DotController extends BaseController {

    public static void init(Activity activity) {
        DotManager.getInstance().init(activity);
    }
    public static void init(Context context){
        DotManager.getInstance().init(context);
    }

    public static void open(String openPlatform) {
        DotManager.getInstance().setOpenPlatform(openPlatform);
    }

    public static void logEvent(Map<String, Object> map) {
        DotManager.getInstance().logEvent(map);
    }

    public static void logClick(Map<String, Object> map) {
        DotManager.getInstance().logClick(map);
    }

    public static void onPlayStart(int period) {
        DotManager.getInstance().onPlayStart(period);
    }

    public static void onPlayStop() {
        DotManager.getInstance().onPlayStop();
    }

    public static void onStartPage(Context context) {
        DotManager.getInstance().onStartPage(context);
    }

    public static void onStopPage() {
        DotManager.getInstance().onStopPage();
    }

    public static void logScreen(Map<String, Object> map) {
        DotManager.getInstance().logScreen(map);
    }

    public static void logPurchase(Map<String, Object> map) {
        DotManager.getInstance().logPurchase(map);
    }

    public static void setWebView(WebView webView) {
        DotManager.getInstance().setWebView(webView);
    }

    public static void injectJavascript(WebView webView) {
        DotManager.getInstance().injectJavascript(webView);
    }

    public static Map getAttributedInfo() throws Exception {
        return DotManager.getInstance().getAttributedInfo();
    }

}

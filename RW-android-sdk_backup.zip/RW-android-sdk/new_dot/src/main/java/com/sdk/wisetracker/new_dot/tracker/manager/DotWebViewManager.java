package com.sdk.wisetracker.new_dot.tracker.manager;

import android.webkit.ValueCallback;
import android.webkit.WebView;

import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.manager.WebViewManager;

/**
 * 웹뷰 설정 manager class
 */
public class DotWebViewManager extends WebViewManager {

    private final String DOT_WEB_INTERFACE = "DOT_JS_INTERFACE";
    private static DotWebViewManager instance = null;
    private WebView webView = null;

    public static DotWebViewManager getInstance() {
        if (instance == null) {
            instance = new DotWebViewManager();
        }
        return instance;
    }

    public void setWebView(WebView webView) {
        try {
            if (webView == null) {
                WiseLog.d("web view is null");
                return;
            }
            this.webView = webView;
            this.webView.getSettings().setJavaScriptEnabled(true);
            this.webView.addJavascriptInterface(new DotWebInterfaceManager(), DOT_WEB_INTERFACE); // inject 처리가 되어 있음.

            // RW SDK webview agent 변경
            StringBuilder _userAgent = new StringBuilder();
            _userAgent.append(this.webView.getSettings().getUserAgentString());
            _userAgent.append(" RW2SDK");

            this.webView.getSettings().setUserAgentString(_userAgent.toString());

        } catch (Exception e) {
            WiseLog.e(e);
        }
    }

}
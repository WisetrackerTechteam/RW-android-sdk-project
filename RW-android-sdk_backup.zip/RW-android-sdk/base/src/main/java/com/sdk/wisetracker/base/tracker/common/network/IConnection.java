package com.sdk.wisetracker.base.tracker.common.network;

public interface IConnection {
    void onConnection(boolean isConnect);
}

package com.sdk.wisetracker.base.tracker.data.manager;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;

import com.onestore.android.external.installreferrer.IGetInstallReferrerService;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitInstallReferrer;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;

import java.net.URLDecoder;

public class FacebookReferrerDataManager {
    private static FacebookReferrerDataManager instance = null;
    public static FacebookReferrerDataManager getInstance() {
        if (instance == null) {
            instance = new FacebookReferrerDataManager();
        }
        return instance;
    }

    /**
     * Referrer Details
     */
    public FacebookReferrerDataManager.ReferrerDetails mReferrerDetails;
    public FacebookReferrerDataManager.ReferrerDetails getEmptyReferrer(){
        return new FacebookReferrerDataManager.ReferrerDetails();
    }

    public void setReferrerData( String referrer, long clickTime ){
        if( mReferrerDetails == null ){
            mReferrerDetails = new ReferrerDetails();
        }
        mReferrerDetails.installReferrer = referrer;
        mReferrerDetails.referrerClickTimeStampSeconds = clickTime;
    }

    public class ReferrerDetails {
        public String installReferrer;

        public String getInstallReferrer() {
            return this.installReferrer;
        }

        public long referrerClickTimeStampSeconds;
        public long getReferrerClickTimestampSeconds() {
            return this.referrerClickTimeStampSeconds;
        }

        public ReferrerDetails() {
            this.installReferrer = "";
            this.referrerClickTimeStampSeconds = 0;
        }
    }
}

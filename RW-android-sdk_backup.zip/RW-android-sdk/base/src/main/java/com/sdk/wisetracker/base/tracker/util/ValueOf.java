package com.sdk.wisetracker.base.tracker.util;

import android.text.TextUtils;

/**
 * 타입 convert util class
 */
public class ValueOf {

    public static long longValue(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        return Long.valueOf(value);
    }

    public static int intValue(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        return Integer.valueOf(value);
    }

    public static String isNullEmptyString(Object obj, String value){
        if (TextUtils.isEmpty(value)) {
            return value;
        }else{
            return (String)obj;
        }
    }

}

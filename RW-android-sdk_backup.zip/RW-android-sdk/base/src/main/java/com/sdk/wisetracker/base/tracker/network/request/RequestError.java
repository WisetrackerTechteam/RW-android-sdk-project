package com.sdk.wisetracker.base.tracker.network.request;

import com.google.gson.annotations.SerializedName;

/**
 * SDK 오류 발생시 API 서버에 전달하는 데이터 클래스
 */
public class RequestError {

    private @SerializedName("_wtno") String serviceNumber = null;
    private @SerializedName("errlog") String errLog = null;
    private @SerializedName("wtref") String deepLink = null;
    private @SerializedName("installReferrer") String installReferrer = null;
    private @SerializedName("advtId") String adId = null;
    private @SerializedName("lng") String language = null;
    private @SerializedName("cntr") String country = null;
    private @SerializedName("tz") String timeZone = null;
    private @SerializedName("os") String os = null;
    private @SerializedName("phone") String deviceModel = null;
    private @SerializedName("apVr") String appVersion = null;
    private @SerializedName("plat") String platform = "AOS";
    private @SerializedName("vendorId") String vendor = null;
    private @SerializedName("advtFlag") int adFlag = -1;

    public void setServiceNumber(String serviceNumber) {
        this.serviceNumber = serviceNumber;
    }

    public void setErrLog(String errLog) {
        this.errLog = errLog;
    }

    public void setDeepLink(String deepLink) {
        this.deepLink = deepLink;
    }

    public void setInstallReferrer(String installReferrer) {
        this.installReferrer = installReferrer;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public void setAdFlag(int adFlag) {
        this.adFlag = adFlag;
    }

}

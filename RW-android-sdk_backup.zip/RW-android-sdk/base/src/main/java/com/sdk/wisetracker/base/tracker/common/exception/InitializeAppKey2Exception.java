package com.sdk.wisetracker.base.tracker.common.exception;

/**
 * 초기화 키 설정 오류 Exception
 */
public class InitializeAppKey2Exception extends DopException {

    public InitializeAppKey2Exception() {
        super(ExceptionCode.INITIALIZE_APP_KEY2_ERROR);
    }

}

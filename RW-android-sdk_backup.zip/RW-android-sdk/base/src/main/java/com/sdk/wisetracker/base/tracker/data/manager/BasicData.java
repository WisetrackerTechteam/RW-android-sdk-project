package com.sdk.wisetracker.base.tracker.data.manager;

/**
 * SDK 기본 정보 확인 내부 저장용 데이터 모델 클래스
 */
public class BasicData {

    // install
    public boolean isFirstOpenInSession = true;
    private String isFirstAppOpen = "Y";
    private long firstAppOpenTime = 0;

    // event time
    private long lastSessionTime = 0;
    private long lastAppEventTime = 0;
    private long lastPurchaseTime = 0;
    private long lastFingerPrintTime = 0;
    private long lastRetentionTime = 0;

    // token
    private String token = null;
    private long tokenExpireTime = 0;

    // ntp.device time difference
    private long timeDiff = 0;

    public boolean getIsFirstOpenInSession(){
        return this.isFirstOpenInSession;
    }
    public void setIsFirstOpenInSession(boolean flag){
        this.isFirstOpenInSession = flag;
    }

    public String getIsFirstAppOpen() {
        return isFirstAppOpen;
    }

    public void setIsFirstAppOpen(String isFirstAppOpen) {
        this.isFirstAppOpen = isFirstAppOpen;
    }

    public long getFirstAppOpenTime() {
        return firstAppOpenTime;
    }

    public void setFirstAppOpenTime(long firstAppOpenTime) {
        this.firstAppOpenTime = firstAppOpenTime;
    }

    public long getLastSessionTime() {
        return lastSessionTime;
    }

    public void setLastSessionTime(long lastSessionTime) {
        this.lastSessionTime = lastSessionTime;
    }

    public long getLastAppEventTime() {
        return lastAppEventTime;
    }

    public void setLastAppEventTime(long lastAppEventTime) {
        this.lastAppEventTime = lastAppEventTime;
    }

    public long getLastPurchaseTime() {
        return lastPurchaseTime;
    }

    public void setLastPurchaseTime(long lastPurchaseTime) {
        this.lastPurchaseTime = lastPurchaseTime;
    }

    public long getLastFingerPrintTime() {
        return lastFingerPrintTime;
    }

    public void setLastFingerPrintTime(long lastFingerPrintTime) {
        this.lastFingerPrintTime = lastFingerPrintTime;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public long getTokenExpireTime() {
        return tokenExpireTime;
    }

    public void setTokenExpireTime(long tokenExpireTime) {
        this.tokenExpireTime = tokenExpireTime;
    }

    public long getTimeDiff() {
        return timeDiff;
    }

    public void setTimeDiff(long timeDiff) {
        this.timeDiff = timeDiff;
    }

    public long getLastRetentionTime() {
        return lastRetentionTime;
    }

    public void setLastRetentionTime(long lastRetentionTime) {
        this.lastRetentionTime = lastRetentionTime;
    }
}

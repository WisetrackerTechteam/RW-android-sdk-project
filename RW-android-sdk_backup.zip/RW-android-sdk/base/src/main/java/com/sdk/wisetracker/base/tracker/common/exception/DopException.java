package com.sdk.wisetracker.base.tracker.common.exception;

/**
 * 예외 처리 Base class
 */
public class DopException extends Exception {

    private ExceptionCode exceptionCode;

    public DopException(ExceptionCode exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    public int getErrorCode() {
        return exceptionCode.getErrorCode();
    }

    public String getDescription() {
        return exceptionCode.getDescription();
    }

}

package com.sdk.wisetracker.base.tracker.util;

import com.sdk.wisetracker.base.tracker.common.log.WiseLog;

import org.apache.commons.net.util.Base64;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * API 통신 암호화 처리 util class
 */
public class AES256Util {

    private static AES256Util instance = null;
    private Key keySpec;
    private String iv;

    public static AES256Util getInstance() {
        if (instance == null) {
            instance = new AES256Util();
        }
        return instance;
    }

    public void setSeedKey(String seedKey) throws UnsupportedEncodingException {
        this.iv = seedKey.substring(0, 16);
        byte[] keyBytes = new byte[16];
        byte[] b = seedKey.getBytes("UTF-8");
        int len = b.length;
        if (len > keyBytes.length) {
            len = keyBytes.length;
        }
        System.arraycopy(b, 0, keyBytes, 0, len);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
        this.keySpec = keySpec;
    }

    // 암호화
    public String aesEncode(String seedKey, String value) throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        if (keySpec == null) {
            setSeedKey(seedKey);
        }
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes()));
        byte[] encrypted = c.doFinal(value.getBytes("UTF-8"));
        String enStr = new String(Base64.encodeBase64(encrypted));
        WiseLog.d("aseEncode:"+value+"==>"+enStr);
        return enStr;
    }

    // 복호화
    public String aesDecode(String seedKey, String value) throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        if (keySpec == null) {
            setSeedKey(seedKey);
        }
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes("UTF-8")));
        byte[] byteStr = Base64.decodeBase64(value.getBytes());
        String deStr = new String(c.doFinal(byteStr), "UTF-8");
        WiseLog.d("aesDecode:"+value+"==>"+deStr);
        return deStr;
    }

}

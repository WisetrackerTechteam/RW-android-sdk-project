package com.sdk.wisetracker.base.open.model;


import com.google.gson.annotations.SerializedName;

/**
 * 캠페인 SDK 전달 모델 객체
 */
public class InternalCampaign {

    private @SerializedName("inrc1") String inrc1;
    private @SerializedName("inrcTime1") long inrcTime1;
    private @SerializedName("inrcDt1") int inrcDt1;

    private @SerializedName("inrc2") String inrc2;
    private @SerializedName("inrcTime2") long inrcTime2;
    private @SerializedName("inrcDt2") int inrcDt2;

    private @SerializedName("inrc3") String inrc3;
    private @SerializedName("inrcTime3") long inrcTime3;
    private @SerializedName("inrcDt3") int inrcDt3;

    private @SerializedName("inrc4") String inrc4;
    private @SerializedName("inrcTime4") long inrcTime4;
    private @SerializedName("inrcDt4") int inrcDt4;

    private @SerializedName("inrc5") String inrc5;
    private @SerializedName("inrcTime5") long inrcTime5;
    private @SerializedName("inrcDt5") int inrcDt5;

    private @SerializedName("inrc6") String inrc6;
    private @SerializedName("inrcTime6") long inrcTime6;
    private @SerializedName("inrcDt6") int inrcDt6;

    private @SerializedName("inrc7") String inrc7;
    private @SerializedName("inrcTime7") long inrcTime7;
    private @SerializedName("inrcDt7") int inrcDt7;

    private @SerializedName("inrc8") String inrc8;
    private @SerializedName("inrcTime8") long inrcTime8;
    private @SerializedName("inrcDt8") int inrcDt8;

    private @SerializedName("inrc9") String inrc9;
    private @SerializedName("inrcTime9") long inrcTime9;
    private @SerializedName("inrcDt9") int inrcDt9;

    private @SerializedName("inrc10") String inrc10;
    private @SerializedName("inrcTime10") long inrcTime10;
    private @SerializedName("inrcDt10") int inrcDt10;


    public String getInrc1() {        return inrc1;    }
    public long getInrcTime1() {        return inrcTime1;    }
    public int getInrcDt1() {        return inrcDt1;    }

    public String getInrc2() {        return inrc2;    }
    public long getInrcTime2() {        return inrcTime2;    }
    public int getInrcDt2() {        return inrcDt2;    }

    public String getInrc3() {        return inrc3;    }
    public long getInrcTime3() {        return inrcTime3;    }
    public int getInrcDt3() {        return inrcDt3;    }

    public String getInrc4() {        return inrc4;    }
    public long getInrcTime4() {        return inrcTime4;    }
    public int getInrcDt4() {        return inrcDt4;    }

    public String getInrc5() {        return inrc5;    }
    public long getInrcTime5() {        return inrcTime5;    }
    public int getInrcDt5() {        return inrcDt5;    }

    public String getInrc6() {        return inrc6;    }
    public long getInrcTime6() {        return inrcTime6;    }
    public int getInrcDt6() {        return inrcDt6;    }

    public String getInrc7() {        return inrc7;    }
    public long getInrcTime7() {        return inrcTime7;    }
    public int getInrcDt7() {        return inrcDt7;    }

    public String getInrc8() {        return inrc8;    }
    public long getInrcTime8() {        return inrcTime8;    }
    public int getInrcDt8() {        return inrcDt8;    }

    public String getInrc9() {        return inrc9;    }
    public long getInrcTime9() {        return inrcTime9;    }
    public int getInrcDt9() {        return inrcDt9;    }

    public String getInrc10() {        return inrc10;    }
    public long getInrcTime10() {        return inrcTime10;    }
    public int getInrcDt10() {        return inrcDt10;    }



    public InternalCampaign(Builder builder) {

        this.inrc1 = builder.inrc1;
        this.inrcTime1 = builder.inrcTime1;
        this.inrcDt1 = builder.inrcDt1;

        this.inrc2 = builder.inrc2;
        this.inrcTime2 = builder.inrcTime2;
        this.inrcDt2 = builder.inrcDt2;

        this.inrc3 = builder.inrc3;
        this.inrcTime3 = builder.inrcTime3;
        this.inrcDt3 = builder.inrcDt3;

        this.inrc4 = builder.inrc4;
        this.inrcTime4 = builder.inrcTime4;
        this.inrcDt4 = builder.inrcDt4;

        this.inrc5 = builder.inrc5;
        this.inrcTime5 = builder.inrcTime5;
        this.inrcDt5 = builder.inrcDt5;

        this.inrc6 = builder.inrc6;
        this.inrcTime6 = builder.inrcTime6;
        this.inrcDt6 = builder.inrcDt6;

        this.inrc7 = builder.inrc7;
        this.inrcTime7 = builder.inrcTime7;
        this.inrcDt7 = builder.inrcDt7;

        this.inrc8 = builder.inrc8;
        this.inrcTime8 = builder.inrcTime8;
        this.inrcDt8 = builder.inrcDt8;

        this.inrc9 = builder.inrc9;
        this.inrcTime9 = builder.inrcTime9;
        this.inrcDt9 = builder.inrcDt9;

        this.inrc10 = builder.inrc10;
        this.inrcTime10 = builder.inrcTime10;
        this.inrcDt10 = builder.inrcDt10;
    }


    public static class Builder {

        private String inrc1 = null;
        private long inrcTime1 = 0;
        private int inrcDt1 = 0;

        private String inrc2 = null;
        private long inrcTime2 = 0;
        private int inrcDt2 = 0;

        private String inrc3 = null;
        private long inrcTime3 = 0;
        private int inrcDt3 = 0;

        private String inrc4 = null;
        private long inrcTime4 = 0;
        private int inrcDt4 = 0;

        private String inrc5 = null;
        private long inrcTime5 = 0;
        private int inrcDt5 = 0;

        private String inrc6 = null;
        private long inrcTime6 = 0;
        private int inrcDt6 = 0;

        private String inrc7 = null;
        private long inrcTime7 = 0;
        private int inrcDt7 = 0;

        private String inrc8 = null;
        private long inrcTime8 = 0;
        private int inrcDt8 = 0;

        private String inrc9 = null;
        private long inrcTime9 = 0;
        private int inrcDt9 = 0;

        private String inrc10 = null;
        private long inrcTime10 = 0;
        private int inrcDt10 = 0;

        public Builder setInternalCampaign1(String campaignId, int days){
            this.inrc1 = campaignId;
            this.inrcTime1 = System.currentTimeMillis();
            this.inrcDt1 = days;
            return this;
        }
        public Builder setInternalCampaign2(String campaignId, int days){
            this.inrc2 = campaignId;
            this.inrcTime2 = System.currentTimeMillis();
            this.inrcDt2 = days;
            return this;
        }
        public Builder setInternalCampaign3(String campaignId, int days){
            this.inrc3 = campaignId;
            this.inrcTime3 = System.currentTimeMillis();
            this.inrcDt3 = days;
            return this;
        }
        public Builder setInternalCampaign4(String campaignId, int days){
            this.inrc4 = campaignId;
            this.inrcTime4 = System.currentTimeMillis();
            this.inrcDt4 = days;
            return this;
        }
        public Builder setInternalCampaign5(String campaignId, int days){
            this.inrc5 = campaignId;
            this.inrcTime5 = System.currentTimeMillis();
            this.inrcDt5 = days;
            return this;
        }
        public Builder setInternalCampaign6(String campaignId, int days){
            this.inrc6 = campaignId;
            this.inrcTime6 = System.currentTimeMillis();
            this.inrcDt6 = days;
            return this;
        }
        public Builder setInternalCampaign7(String campaignId, int days){
            this.inrc7 = campaignId;
            this.inrcTime7 = System.currentTimeMillis();
            this.inrcDt7 = days;
            return this;
        }
        public Builder setInternalCampaign8(String campaignId, int days){
            this.inrc8 = campaignId;
            this.inrcTime8 = System.currentTimeMillis();
            this.inrcDt8 = days;
            return this;
        }
        public Builder setInternalCampaign9(String campaignId, int days){
            this.inrc9 = campaignId;
            this.inrcTime9 = System.currentTimeMillis();
            this.inrcDt9 = days;
            return this;
        }
        public Builder setInternalCampaign10(String campaignId, int days){
            this.inrc10 = campaignId;
            this.inrcTime10 = System.currentTimeMillis();
            this.inrcDt10 = days;
            return this;
        }
        public InternalCampaign build() {
            return new InternalCampaign(this);
        }
    }
}

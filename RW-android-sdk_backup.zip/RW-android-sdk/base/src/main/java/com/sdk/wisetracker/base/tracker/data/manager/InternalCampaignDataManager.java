package com.sdk.wisetracker.base.tracker.data.manager;

import com.sdk.wisetracker.base.open.model.InternalCampaign;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.model.Session;
import com.sdk.wisetracker.base.tracker.util.ValueOf;

import java.util.Calendar;

public class InternalCampaignDataManager extends BaseDataManager {

    private static InternalCampaignDataManager instance = null;

    public static InternalCampaignDataManager getInstance() {
        if (instance == null) {
            instance = new InternalCampaignDataManager();
        }
        return instance;
    }
    public void setInternalCampaign(InternalCampaign campaign){
        try {
            if( campaign != null ){
                Session session = SessionDataManager.getInstance().getSession();
                if( campaign.getInrc1() != null && !campaign.getInrc1().equals("")){
                    session.setInrc1(campaign.getInrc1());
                    session.setInrcTime1(campaign.getInrcTime1());
                    session.setInrcDt1(campaign.getInrcDt1());
                }
                if( campaign.getInrc2() != null && !campaign.getInrc2().equals("")){
                    session.setInrc2(campaign.getInrc2());
                    session.setInrcTime2(campaign.getInrcTime2());
                    session.setInrcDt2(campaign.getInrcDt2());
                }
                if( campaign.getInrc3() != null && !campaign.getInrc3().equals("")){
                    session.setInrc3(campaign.getInrc3());
                    session.setInrcTime3(campaign.getInrcTime3());
                    session.setInrcDt3(campaign.getInrcDt3());
                }
                if( campaign.getInrc4() != null && !campaign.getInrc4().equals("")){
                    session.setInrc4(campaign.getInrc4());
                    session.setInrcTime4(campaign.getInrcTime4());
                    session.setInrcDt4(campaign.getInrcDt4());
                }
                if( campaign.getInrc5() != null && !campaign.getInrc5().equals("")){
                    session.setInrc5(campaign.getInrc5());
                    session.setInrcTime5(campaign.getInrcTime5());
                    session.setInrcDt5(campaign.getInrcDt5());
                }
                if( campaign.getInrc6() != null && !campaign.getInrc6().equals("")){
                    session.setInrc6(campaign.getInrc6());
                    session.setInrcTime6(campaign.getInrcTime6());
                    session.setInrcDt6(campaign.getInrcDt6());
                }
                if( campaign.getInrc7() != null && !campaign.getInrc7().equals("")){
                    session.setInrc7(campaign.getInrc7());
                    session.setInrcTime7(campaign.getInrcTime7());
                    session.setInrcDt7(campaign.getInrcDt7());
                }
                if( campaign.getInrc8() != null && !campaign.getInrc8().equals("")){
                    session.setInrc8(campaign.getInrc8());
                    session.setInrcTime8(campaign.getInrcTime8());
                    session.setInrcDt8(campaign.getInrcDt8());
                }
                if( campaign.getInrc9() != null && !campaign.getInrc9().equals("")){
                    session.setInrc9(campaign.getInrc9());
                    session.setInrcTime9(campaign.getInrcTime9());
                    session.setInrcDt9(campaign.getInrcDt9());
                }
                if( campaign.getInrc10() != null && !campaign.getInrc10().equals("")){
                    session.setInrc10(campaign.getInrc10());
                    session.setInrcTime10(campaign.getInrcTime10());
                    session.setInrcDt10(campaign.getInrcDt10());
                }
                SessionDataManager.getInstance().saveSession(session);
            }
        }catch(Exception e){
            WiseLog.e(e);
        }
    }
    private void checkValidation(){
        Session session = SessionDataManager.getInstance().getSession();
        if( session != null ){
            if(session.getInrc1() != null && this.isExpire( session.getInrcTime1(), session.getInrcDt1() )){
                session.setInrc1(null);
                session.setInrcTime1(0);
                session.setInrcDt1(0);
            }
            if(session.getInrc2() != null && this.isExpire( session.getInrcTime2(), session.getInrcDt2() )){
                session.setInrc2(null);
                session.setInrcTime2(0);
                session.setInrcDt2(0);
            }
            if(session.getInrc3() != null && this.isExpire( session.getInrcTime3(), session.getInrcDt3() )){
                session.setInrc3(null);
                session.setInrcTime3(0);
                session.setInrcDt3(0);
            }
            if(session.getInrc4() != null && this.isExpire( session.getInrcTime4(), session.getInrcDt4() )){
                session.setInrc4(null);
                session.setInrcTime4(0);
                session.setInrcDt4(0);
            }
            if(session.getInrc5() != null && this.isExpire( session.getInrcTime5(), session.getInrcDt5() )){
                session.setInrc5(null);
                session.setInrcTime5(0);
                session.setInrcDt5(0);
            }
            if(session.getInrc6() != null && this.isExpire( session.getInrcTime6(), session.getInrcDt6() )){
                session.setInrc6(null);
                session.setInrcTime6(0);
                session.setInrcDt6(0);
            }
            if(session.getInrc7() != null && this.isExpire( session.getInrcTime7(), session.getInrcDt7() )){
                session.setInrc7(null);
                session.setInrcTime7(0);
                session.setInrcDt7(0);
            }
            if(session.getInrc8() != null && this.isExpire( session.getInrcTime8(), session.getInrcDt8() )){
                session.setInrc8(null);
                session.setInrcTime8(0);
                session.setInrcDt8(0);
            }
            if(session.getInrc9() != null && this.isExpire( session.getInrcTime9(), session.getInrcDt9() )){
                session.setInrc9(null);
                session.setInrcTime9(0);
                session.setInrcDt9(0);
            }
            if(session.getInrc10() != null && this.isExpire( session.getInrcTime10(), session.getInrcDt10() )){
                session.setInrc10(null);
                session.setInrcTime10(0);
                session.setInrcDt10(0);
            }
        }
    }
    private boolean isExpire(long time, int expire){
        boolean flag = true;
        if( time > 0 && expire > 0 ){
            Calendar _eventTime = Calendar.getInstance();
            _eventTime.setTimeInMillis(time);
            _eventTime.add(Calendar.DAY_OF_MONTH,expire);
            if( System.currentTimeMillis() < _eventTime.getTimeInMillis()){
                System.out.println("success");
                flag = false;
            }
        }
        return flag;
    }
    @Override
    public void setData() {
        this.checkValidation();
    }
}

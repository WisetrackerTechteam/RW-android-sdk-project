package com.sdk.wisetracker.base.tracker.data.manager;

import com.sdk.wisetracker.base.open.model.User;
import com.sdk.wisetracker.base.tracker.data.model.Session;

/**
 * 유저 데이터 수신시 세션에 유저 정보 추가 class
 */
public class UserDataManager {

    private static UserDataManager instance = null;

    public static UserDataManager getInstance() {
        if (instance == null) {
            instance = new UserDataManager();
        }
        return instance;
    }

    public void setUser(User user) {
        Session session = SessionDataManager.getInstance().getSession();
        session.setLogin(user.isLogin());
        session.setAge(user.getAge());
        session.setGender(user.getGender());
        session.setAttribute1(user.getAttr1());
        session.setAttribute2(user.getAttr2());
        session.setAttribute3(user.getAttr3());
        session.setAttribute4(user.getAttr4());
        session.setAttribute5(user.getAttr5());
        session.setMember(user.getMember());
        session.setMemberGrade(user.getMemberGrade());
        session.setMember(user.getMemberId());
        session.setLoginTp(user.getLoginTp());
        session.setSignupTp(user.getSignupTp());
        SessionDataManager.getInstance().saveSession(session);
    }

    public void setUserLogout() {
        Session session = SessionDataManager.getInstance().getSession();
        session.setLogin(false);
        session.setAge(null);
        session.setGender(null);
        session.setAttribute1(null);
        session.setAttribute2(null);
        session.setAttribute3(null);
        session.setAttribute4(null);
        session.setAttribute5(null);
        session.setMember(null);
        session.setMemberGrade(null);
        session.setMember(null);
        session.setLoginTp(null);
        session.setSignupTp(null);
        SessionDataManager.getInstance().saveSession(session);
    }

    public void setUserId(String userId) {
        Session session = SessionDataManager.getInstance().getSession();
        session.setUserId(userId);
        SessionDataManager.getInstance().saveSession(session);
    }

}

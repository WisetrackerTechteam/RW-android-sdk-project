package com.sdk.wisetracker.base.tracker.data.manager;

import android.annotation.SuppressLint;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;
import com.sdk.wisetracker.base.tracker.data.model.Session;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.subjects.PublishSubject;

public class InAppMessageDataManager extends BaseDataManager {

    private static InAppMessageDataManager instance = null;
    public static InAppMessageDataManager getInstance() {
        if (instance == null) {
            instance = new InAppMessageDataManager();
        }
        return instance;
    }
    @Override
    public void setData() {
        this.checkValidation();
    }

    /**
     * Session 에 저장된 in-app message 관련 데이터 벨리데이션 함수
     * 노출 빈도 만료된 데이터 처리 & 저장된 message id 초기화.
     **/
    private void checkValidation(){
        // 1. couchbase에서 값을 읽어와서, 기간 체크 및 만료 메시지 아이디 갱신
        try{

            boolean needToUpdate = false;

            // 1. 노출 빈도수에 의해서 차단되던 메시지가 해제 된게 있으면 삭제 처리 해줌.
            List<String> deletedFrequencyId = new ArrayList<>();
            JsonArray receivedInAppMessageData = this.getReceivedInAppMessageData(session.getReceivedInAppMessageData());
            WiseLog.d("receivedInAppMessageData ( device ) : " + receivedInAppMessageData);
            if( receivedInAppMessageData != null & receivedInAppMessageData.size() > 0 ) {
                for (int i = 0; i < receivedInAppMessageData.size(); i++) {
                    JsonObject msg = (JsonObject)receivedInAppMessageData.get(i);

                    // 1. get viewTime
                    long viewTime = msg.get("viewTime").getAsLong();

                    // 2. viewTime + frequencyLimitDay ( d,w,m )
                    String dateType = msg.get("dateType").getAsString();
                    int fDayCount = msg.get("frequencyLimitDay").getAsInt();

                    // 3. current time vs expire time
                    Calendar expireTime = Calendar.getInstance();
                    expireTime.setTimeInMillis(viewTime);
                    switch (dateType){
                        case "D": expireTime.add(Calendar.DAY_OF_MONTH,fDayCount); break;
                        case "W": expireTime.add(Calendar.WEEK_OF_YEAR,fDayCount); break;
                        case "M": expireTime.add(Calendar.MONTH,fDayCount); break;
                    }

                    // 현재 시간이 만료 시간이 이미 지난 경우는 삭제될 아이디 배열에 추가. ( 아래에서 삭제함 )
                    if( System.currentTimeMillis() > expireTime.getTimeInMillis() ){
                        deletedFrequencyId.add(msg.get("mk").getAsString());
                        WiseLog.d("delete Msg " + msg );
                    }
                }

                // 노출 빈도가 해제된 메시지가 있으면 삭제 처리.
                if( deletedFrequencyId.size() > 0 ){
                    JsonArray updateReceivedInAppMessageData = new JsonArray();
                    for(int i = 0; i < receivedInAppMessageData.size(); i++) {
                        JsonObject msg = (JsonObject)receivedInAppMessageData.get(i);
                        if(!deletedFrequencyId.contains(msg.get("mk").getAsString())){
                            updateReceivedInAppMessageData.add(msg);
                        }
                    }

                    receivedInAppMessageData = new JsonArray();
                    receivedInAppMessageData.addAll(updateReceivedInAppMessageData);
                    session.setReceivedInAppMessageData(new Gson().toJson(updateReceivedInAppMessageData));
                    needToUpdate = true;
                }
            }


            // 2. Session 데이터에 존재하는 inapp message id 값에 대한 lookback window 체크해서 초기화 검사.
            String inappmessageId = session.getInappMessageId();
            long inappMessageExpireTime = session.getInappMessageExpierTime();
            if( inappmessageId != null &&
                !inappmessageId.equals("") &&
                inappMessageExpireTime > 0 &&
                inappMessageExpireTime < System.currentTimeMillis() ){
                    session.setInappMessageId("");
                    session.setInappMessageClickTime(0);
                    session.setInappMessageExpierTime(0);
                    needToUpdate = true;
            }

            // 3. alreadSeeenId 갱신
            if( receivedInAppMessageData != null && receivedInAppMessageData.size() > 0 ){
                StringBuilder alreadySeenIds = new StringBuilder();
                for (int i = 0; i < receivedInAppMessageData.size(); i++) {
                    JsonObject msg = (JsonObject) receivedInAppMessageData.get(i);
                    if( alreadySeenIds.length() > 0 ){
                        alreadySeenIds.append("|").append(msg.get("mk").getAsString());
                    }else{
                        alreadySeenIds.append(msg.get("mk").getAsString());
                    }
                }
                if( !(alreadySeenIds.toString()).equals("") &&
                    alreadySeenIds.length() > 0) {
                    session.setAlreadySeenCampaignId(alreadySeenIds.toString());
                    needToUpdate = true;
                }
            }

            // 4. session save
            if( needToUpdate ){
                SessionDataManager.getInstance().saveSession(session);
            }

        }catch(Exception e){
            WiseLog.e(e);
        }
    }

    /**
     * In-App Message impression data send
     * **/
    public boolean displayInAppMessageId(String newInAppMessageId, JsonObject frequency){
        boolean flag = false;
        try{
            // start & end 날짜 검증하고 저장함.
            long now = System.currentTimeMillis();

            // 1. 해당 캠페인이 집행 기간이 유효한지 확인하고,
            if( now >= frequency.get("start").getAsLong() &&  now <= frequency.get("end").getAsLong()){

                // 노출 빈도에 차단되는지 점검하고
                JsonArray receivedInAppMessageData = this.getReceivedInAppMessageData(session.getReceivedInAppMessageData());
                boolean isFrequency = this.checkFrequencyStatus(receivedInAppMessageData, newInAppMessageId );
                if( isFrequency ){

                    // 1. 전달 받은 메시지 아이디를 추가
                    frequency.addProperty("mk", newInAppMessageId);

                    // alreadySeenId 에 append 로직
                    receivedInAppMessageData.add(frequency); // add New
                    session.setReceivedInAppMessageData(new Gson().toJson(receivedInAppMessageData));
                    WiseLog.d("receive str ( add )  : " + session.getReceivedInAppMessageData() );

                    StringBuilder alreadyBuf = new StringBuilder();
                    for(int rx = 0; rx < receivedInAppMessageData.size(); rx++){
                        if( alreadyBuf.length() > 0 ){
                            alreadyBuf.append("|");
                        }
                        JsonObject msg = (JsonObject) receivedInAppMessageData.get(rx);
                        alreadyBuf.append(msg.get("mk").getAsString());
                    }
                    session.setAlreadySeenCampaignId(alreadyBuf.toString());
                    SessionDataManager.getInstance().saveSession(session);

                    flag = true;
                    WiseLog.d("------------------------------");
                    WiseLog.d(session.getAlreadySeenCampaignId());
                    WiseLog.d(session.getReceivedInAppMessageData());
                    WiseLog.d("New In-app message data saved to Session ( Impression :  alreadySeenId, receivedData1  ). ("+session.getAlreadySeenCampaignId()+")");
                    WiseLog.d("------------------------------");
                 }
            }
        }catch(Exception e){
            WiseLog.e(e);
        }
        return flag;
    }


    /**
     * In-App Message click data send
     * **/
    public boolean updateInAppMessageId(String newInAppMessageId, JsonObject frequency){
        boolean flag = false;
        try{
            // 노출 빈도에 차단되는지 점검하고
            JsonArray receivedInAppMessageData = this.getReceivedInAppMessageData(session.getReceivedInAppMessageData());

            // 1. 전달 받은 메시지 아이디를 클릭하여 본 것으로 처리
            session.setInappMessageId(frequency.get("mk").getAsString());
            session.setInappMessageClickTime(frequency.get("viewTime").getAsLong());

            // 2. viewTime + frequencyLimitDay ( d,w,m )
            String dateType = frequency.get("dateType").getAsString();
            int fDayCount = frequency.get("frequencyLimitDay").getAsInt();

            // 3. current time vs expire time
            Calendar expireTime = Calendar.getInstance();
            switch (dateType){
                case "D": expireTime.add(Calendar.DAY_OF_MONTH,fDayCount); break;
                case "W": expireTime.add(Calendar.WEEK_OF_YEAR,fDayCount); break;
                case "M": expireTime.add(Calendar.MONTH,fDayCount); break;
            }
            session.setInappMessageExpierTime(expireTime.getTimeInMillis());
            SessionDataManager.getInstance().saveSession(session);

            flag = true;
            WiseLog.d("New In-app message data saved to Session ( Click event ). ("+frequency.get("mk").getAsString()+")");
        }catch(Exception e){
            WiseLog.e(e);
        }
        return flag;
    }

    /**
     * 전달받은 message Id 가 지금 보여줘도 되는지 노출 빈도를 체크하는 함수.
     * true : 보여줘도 됨.
     * false : 보여주면 안됨.
     **/
    private boolean checkFrequencyStatus(JsonArray receivedData, String messageId){
        boolean flag = true;
        try{
            if( receivedData != null & receivedData.size() > 0 ){
                for(int i = 0; i < receivedData.size(); i++){
                    JsonObject msg = (JsonObject) receivedData.get(i);
                    if( (msg.get("mk").getAsString()).equals(messageId) ){
                        // 1. get viewTime
                        long viewTime = msg.get("viewTime").getAsLong();

                        // 2. viewTime + frequencyLimitDay ( d,w,m )
                        /*
                         * {"dateType":"D",
                         *  "frequencyLimitDay":7,
                         *  "start":1607908607000,
                         *  "lookback":7,
                         *  "end":1615339007000,
                         *  "frequencyLimit":1,
                         *  "viewTime":1610690569908}
                         **/
                        String dateType = msg.get("dateType").getAsString();
                        int fDayCount = msg.get("frequencyLimitDay").getAsInt();

                        // 3. current time vs expire time
                        Calendar expireTime = Calendar.getInstance();
                        expireTime.setTimeInMillis(viewTime);
                        switch (dateType){
                            case "D": expireTime.add(Calendar.DAY_OF_MONTH,fDayCount); break;
                            case "W": expireTime.add(Calendar.WEEK_OF_YEAR,fDayCount); break;
                            case "M": expireTime.add(Calendar.MONTH,fDayCount); break;
                        }
                        // 현재 시간이 만료 시간을 이미 지나지 않은 경우에는 보여주면 안됨.
                        if( System.currentTimeMillis() <= expireTime.getTimeInMillis() ){
                            flag = false;
                        }
                        break;
                    }
                }
            }
        }catch(Exception e){
            WiseLog.e(e);
            flag = false;
        }
        return flag;
    }

    /**
     * 저장된 alreadySeenId 를 배열로 리턴하는 함수.
     **/
    private JsonArray getReceivedInAppMessageData(String data) throws Exception{
        JsonArray list = null;
        if( data != null && !data.equals("")){
            // parse
            JsonParser parser = new JsonParser();
            list = (JsonArray)parser.parse(data);
        }else{
            list = new JsonArray();
        }
        return list;
    }



}

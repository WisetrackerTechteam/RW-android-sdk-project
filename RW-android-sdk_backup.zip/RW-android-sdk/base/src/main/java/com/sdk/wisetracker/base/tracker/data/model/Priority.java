package com.sdk.wisetracker.base.tracker.data.model;

import com.google.gson.annotations.SerializedName;

/**
 * SDK 내부 사용 Priority 모델
 */
public class Priority {

    private @SerializedName("ATR001") int clickPriority = 0;
    private @SerializedName("ATR002") int advertisingPriority = 0;
    private @SerializedName("ATR003") int referrerPriority = 0;
    private @SerializedName("ATR004") int fingerPrintPriority = 0;
    private @SerializedName("ATRSAD") int linkId = 0;
    private @SerializedName("ATRLNKID") int appleSearchAd = 0;

    public int getClickPriority() {
        return clickPriority;
    }

    public int getAdvertisingPriority() {
        return advertisingPriority;
    }

    public int getReferrerPriority() {
        return referrerPriority;
    }

    public int getFingerPrintPriority() {
        return fingerPrintPriority;
    }

    public int getLinkId() {
        return linkId;
    }

    public int getAppleSearchAd() {
        return appleSearchAd;
    }

}

package com.sdk.wisetracker.base.tracker.data.model;

/**
 * SDK 내부 사용 상수 class
 */
public class Const {

    // app key
    public static final String[] DOT_APP_KEY = {
            "useMode",
            "_wthst",
            "_wtno",
            "_wtUdays",
            "_wtDebug",
            "_wtUseRetention",
            "_wtUseFingerPrint",
            "_accessToken",
            "domain_x"
    };
    public static final String[] DOX_APP_KEY = {
            "useMode",
            "_wthst",
            "_wtno",
            "_wtDebug",
            "_accessToken",
            "domain_x"
    };

    // referrer
    public static final String WTS = "_wts";
    public static final String WTM = "_wtm";
    public static final String WTC = "_wtc";
    public static final String WTW = "_wtw";
    public static final String WTREF = "_wtref";
    public static final String WTCLKTIME = "_wtclkTime";
    public static final String WTCKP = "_wtckp";
    public static final String WTP = "_wtp";
    public static final String WTAFFID = "_wtaffid";
    public static final String WTBFFID = "_wtbffid";
    public static final String WGCMPID = "_wgcmpid";
    public static final String WTCID = "_wtcid";

    // open referrer
    public static final String DEEPLINK_REFERRER = "android.intent.extra.REFERRER";
    public static final String DEEPLINK_REFERRER_NAME = "android.intent.extra.REFERRER_NAME";

    // facebook referrer
    public static final String FB_TARGET_URL = "target_url";
    public static final String FB_NATIVE_URL = "com.facebook.platform.APPLINK_NATIVE_URL";
    public static final String FB_CLICK_TIME = "click_time";

    // push
    public static final String PUSH_CHANNEL_ID = "RW";
    public static final String PUSH_CHANNEL_NAME = "RW_PUSH";
    public static final String PUSH_EXTRA_DATA = "RW_push_payload_WP";
    public static final String PUSH_ID = "RW_push_payload_SK";
    public static final String PUSH_CAMPAIGN_ID = "RW_push_payload_CK";
    public static final String PUSH_TITLE = "RW_push_payload_TT";
    public static final String PUSH_BODY = "RW_push_payload_BD";
    public static final String PUSH_EXPIRE_TIME = "RW_push_payload_PR";
    public static final String PUSH_IMAGE_URL = "RW_push_payload_IM";
    public static final String PUSH_MOVIE_URL = "RW_push_payload_MV";

    public static final String TOKEN_DECODE_KEY = "dotAmWisetracker";

    public static final String GOOGLE_APP_STORE = "playstore";
    public static final String ONESTORE = "onestore";

}

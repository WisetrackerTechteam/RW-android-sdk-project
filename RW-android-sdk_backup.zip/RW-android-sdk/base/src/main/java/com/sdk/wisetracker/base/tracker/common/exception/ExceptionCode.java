package com.sdk.wisetracker.base.tracker.common.exception;

/**
 * SDK 동작 오류 메시지 코드
 */
public enum ExceptionCode {

    // 초기화 오류 메시지
    INITIALIZE_APP_KEY_ERROR(1000, "register app key in your string.xml or arrays.xml file and confirm name dotAuthorizationKey"),
    INITIALIZE_APP_KEY2_ERROR(2000, "register app key in your AndroidManifest.xml and meta-data");

    private int errorCode;
    private String description;

    ExceptionCode(int errorCode, String description) {
        this.errorCode = errorCode;
        this.description = description;
    }

    public int getErrorCode() {
        return this.errorCode;
    }

    public String getDescription() {
        return this.description;
    }

}


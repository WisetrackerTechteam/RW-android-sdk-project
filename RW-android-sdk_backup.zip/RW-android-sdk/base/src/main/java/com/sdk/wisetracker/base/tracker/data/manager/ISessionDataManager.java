package com.sdk.wisetracker.base.tracker.data.manager;

/**
 * 세션 관련 데이터 매니져 공통 이용 interface
 * (DeepLinkDataManager.InstallReferrerDataManager.PushDataManager.VisitDataManager)
 */
public interface ISessionDataManager {
    // 세션 데이터 설정시 호출
    void setData();
    // 데이터 전송 이후 처리 작업시 호출
    void afterTransaction();
}

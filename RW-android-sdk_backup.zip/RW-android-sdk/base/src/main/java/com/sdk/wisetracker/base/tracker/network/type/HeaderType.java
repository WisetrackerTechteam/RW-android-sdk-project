package com.sdk.wisetracker.base.tracker.network.type;

public enum  HeaderType {
    BASE, DOT, FRP, TOKEN
}

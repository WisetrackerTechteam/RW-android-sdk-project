package com.sdk.wisetracker.base.tracker.data.model;

import com.google.gson.annotations.SerializedName;

/**
 * SDK 내부 사용 Token 모델
 */
public class Token {

    private @SerializedName("token") String rawData = null;
    private long expireTime = 0;

    public String getRawData() {
        return rawData;
    }

    public void setRawData(String rawData) {
        this.rawData = rawData;
    }

    public long getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(long expireTime) {
        this.expireTime = expireTime;
    }

}

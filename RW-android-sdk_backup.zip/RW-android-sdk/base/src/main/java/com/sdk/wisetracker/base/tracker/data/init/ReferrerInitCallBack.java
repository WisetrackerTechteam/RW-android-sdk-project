package com.sdk.wisetracker.base.tracker.data.init;

/**
 * Referrer 정보 확인 콜백 Interface
 */
public interface ReferrerInitCallBack {
    void onCallback(boolean isComplete);
}

package com.sdk.wisetracker.base.tracker.network.interceptor;

import android.util.Log;

import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.message.InAppMessageKeeper;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * API 호출 후 응답 Raw-Data 확인 Interceptor
 */
public class RetrofitLogInterceptor implements Interceptor {

    private boolean hasInAppMessageBroadcastReceiver = false;

    private String tag;
    public RetrofitLogInterceptor(String tag) {
        this.tag = tag;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        try {
            Request request = chain.request();
            Response response = chain.proceed(request);
            String rawJson = response.body().string();
            WiseLog.d("SERVER RESPONSE -> " + rawJson);
            /*
            * InApp Message check, class loading check
            * SDK 에 inapp message 라이브러리가 존재하는지 검사
            * */
            if( !hasInAppMessageBroadcastReceiver ){
                try{
                    Class.forName("com.sdk.wisetracker.inappmessage.InAppMessageBroadcastReceiver");
                    hasInAppMessageBroadcastReceiver = true;
                }catch(ClassNotFoundException cne){
                    WiseLog.d("Wisetracker inappmessage module not found.");
                }
            }
            /**
             *  inapp message 라이브러리가 같이 임포트가 되어 있으면 서버 응답을 InAppMessageKeeper 로 넘겨줌.
             * **/
            if( hasInAppMessageBroadcastReceiver ){
                InAppMessageKeeper.getInstance().hasInAppMessage(rawJson);
            }
            return response.newBuilder().body(ResponseBody.create(response.body().contentType(), rawJson)).build(); // Re-create the response before returning it because body can be read only once
        } catch (IOException e) {
            Log.e(tag, "retrofit io exception", e);
        } catch (Exception e) {
            Log.e(tag, "retrofit intercept error !!", e);
        }
        return chain.proceed(chain.request().newBuilder().build());

    }

}

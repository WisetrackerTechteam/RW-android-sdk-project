package com.sdk.wisetracker.base.tracker.network.request;

import com.google.gson.annotations.SerializedName;

/**
 * SDK 리텐션 체크시 API 서버에 전달하는 데이터 클래스
 */
public class RequestRetention {

    private @SerializedName("_wtno") String serviceNumber = null;
    private @SerializedName("its") String installChannel = null;
    private @SerializedName("itc") String installCampaign = null;
    private @SerializedName("itm") String installTye = null;
    private @SerializedName("itw") String installKeyword = null;
    private @SerializedName("installTime") long installTime = 0;
    private @SerializedName("lastSendTime") long lastRetentionTime = 0;
    private @SerializedName("advtId") String adId = null;

    public void setServiceNumber(String serviceNumber) {
        this.serviceNumber = serviceNumber;
    }

    public void setInstallChannel(String installChannel) {
        this.installChannel = installChannel;
    }

    public void setInstallCampaign(String installCampaign) {
        this.installCampaign = installCampaign;
    }

    public void setInstallTye(String installTye) {
        this.installTye = installTye;
    }

    public void setInstallKeyword(String installKeyword) {
        this.installKeyword = installKeyword;
    }

    public void setInstallTime(long installTime) {
        this.installTime = installTime;
    }

    public void setLastRetentionTime(long lastRetentionTime) {
        this.lastRetentionTime = lastRetentionTime;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

}

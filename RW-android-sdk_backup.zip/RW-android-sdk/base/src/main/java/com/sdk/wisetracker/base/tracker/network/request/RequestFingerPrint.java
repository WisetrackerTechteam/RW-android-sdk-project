package com.sdk.wisetracker.base.tracker.network.request;

import com.google.gson.annotations.SerializedName;

/**
 * SDK 핑거프린트 요청시 API 서버에 전달하는 데이터 클래스
 */
public class RequestFingerPrint {

    private @SerializedName("_wtno") String serviceNumber;
    private @SerializedName("advtId") String adId;
    private @SerializedName("vendorId") String vendorId;
    private @SerializedName("phone") String deviceModel;
    private @SerializedName("os") String os;
    private @SerializedName("is_new") boolean isNew;
    private @SerializedName("click_time") long clickTime;

    public void setServiceNumber(String serviceNumber) {
        this.serviceNumber = serviceNumber;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public void setVendorId(String vendorId){ this.vendorId = vendorId; }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public void setNew(boolean isNew) {
        this.isNew = isNew;
    }

    public void setClickTime(long clickTime) {
        this.clickTime = clickTime;
    }

}

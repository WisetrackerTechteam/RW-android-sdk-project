package com.sdk.wisetracker.base.tracker.message;

import android.content.Intent;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sdk.wisetracker.base.tracker.common.log.WiseLog;
import com.sdk.wisetracker.base.tracker.data.init.InitializeManager;


public class InAppMessageKeeper {

    private static InAppMessageKeeper instance;
    public static InAppMessageKeeper getInstance(){
        if( instance == null ){
            instance = new InAppMessageKeeper();
        }
        return instance;
    }
    /*
    * 1. 서버에서 응답이 내려온것을 parse 하여 , inapp message 존재 여부 확인
    * 2. 존재할 경우 intent를 사용하여 inapp message sdk쪽으로 데이터 전달.
    **/
    public void hasInAppMessage(String response){
        try{
            JsonParser parser = new JsonParser();
            JsonObject _json = (JsonObject)parser.parse(response);
            if(_json != null){
                if(_json.has("message")){
                    JsonObject message = (JsonObject)_json.get("message");
                    if( message != null && message.size() > 0 ){
                        try{
                            // Intent 전송
                            Intent messageBroadCast = new Intent();
                            messageBroadCast.setAction("com.sdk.wisetracker.inappmessage.RECEIVE_IN_APP_MESSAGE");
                            Gson gson = new Gson();
                            String jsonString = gson.toJson(message);
                            messageBroadCast.putExtra("message",jsonString);
                            LocalBroadcastManager.getInstance(InitializeManager.applicationContext).sendBroadcast(messageBroadCast);
                            WiseLog.d("In-App Message Broadcast success " + messageBroadCast );
                        }catch(Exception se){}
                    }
                }else{
                    WiseLog.d("Not found In-App Message from server response.");
                }
            }
        }catch(Exception e){
            WiseLog.e(e);
        }
    }
}

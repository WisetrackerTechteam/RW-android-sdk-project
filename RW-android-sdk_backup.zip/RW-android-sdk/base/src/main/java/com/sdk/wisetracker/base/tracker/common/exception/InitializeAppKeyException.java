package com.sdk.wisetracker.base.tracker.common.exception;

/**
 * 초기화 키 설정 오류 Exception
 */
public class InitializeAppKeyException extends DopException {

    public InitializeAppKeyException() {
        super(ExceptionCode.INITIALIZE_APP_KEY_ERROR);
    }

}
